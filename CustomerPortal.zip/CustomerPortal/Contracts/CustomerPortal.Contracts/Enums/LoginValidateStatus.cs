﻿namespace Mena.Apis.CustomerPortal.Contracts.Enums
{
    public enum LoginValidateStatus
    {
        NoMatch,
        Valid,
        NoAccount,
        Locked
    }
}
