﻿namespace Mena.Apis.CustomerPortal.Contracts.Enums
{
    public enum PasswordResetStatus
    {
        Error,
        Updated
    }
}
