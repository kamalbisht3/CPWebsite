﻿namespace Mena.Apis.CustomerPortal.Contracts.Enums
{
    public enum UserCreateStaus
    {
        Exists,
        Created
    }
}
