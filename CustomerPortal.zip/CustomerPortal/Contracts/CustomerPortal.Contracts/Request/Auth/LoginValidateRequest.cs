﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.Auth
{
    public class LoginValidateRequest 
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
