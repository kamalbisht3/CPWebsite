﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mena.Apis.CustomerPortal.Contracts.Request.File
{
    public class FileDeleteRequest
    {
        public long UploadimageDataID { get; set; }
        public string EmailID { get; set; }
    }
}
