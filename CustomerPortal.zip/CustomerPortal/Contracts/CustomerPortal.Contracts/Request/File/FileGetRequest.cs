﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.File
{
   public  class FileGetRequest
    {
        public string EmailAddress { get; set; }
    }
}
