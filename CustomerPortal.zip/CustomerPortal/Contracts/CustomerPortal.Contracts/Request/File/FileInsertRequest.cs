﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.File
{
    public class FileInsertRequest
    {
        public byte[] Data { get; set; }
        public string EmailAddress { get; set; }
    }
}
