﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.Policy
{
    public class PolicyInfoRequest
    {
        public string Email { get; set; }
    }
}
