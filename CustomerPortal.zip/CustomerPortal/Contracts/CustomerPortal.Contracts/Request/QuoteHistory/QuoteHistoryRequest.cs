﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.QuoteHistory
{
    public class QuoteHistoryRequest
    {
        public string Email { get; set; }
    }
}
