﻿namespace Mena.Apis.CustomerPortal.Contracts.Request.Vehicle
{
    public class VehicleRequest
    {
        public string Email { get; set; }
    }
}
