﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Auth
{
    public class ForgotLinkResult : IQueryAuthModel
    {
        public Enums.ForgotLinkCreateStaus Status { get; set; }
        public string ResultSet { get; set; }
    }
}
