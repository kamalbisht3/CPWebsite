﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Auth
{
    public class LoginValidateResult : IQueryAuthModel
    {
        public Enums.LoginValidateStatus UserAccountStatus { get; set; }
        public string ResultSet { get; set; }
    }
}
