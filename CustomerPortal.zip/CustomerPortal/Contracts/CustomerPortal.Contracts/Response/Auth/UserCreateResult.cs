﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Auth
{
    public class UserCreateResult : IQueryAuthModel
    {
        public Enums.UserCreateStaus Status { get; set; }
        public string ResultSet { get; set; }
    }
}
