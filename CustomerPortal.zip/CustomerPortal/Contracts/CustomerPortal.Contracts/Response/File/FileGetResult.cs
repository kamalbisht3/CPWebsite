﻿using System;

namespace Mena.Apis.CustomerPortal.Contracts.Response.File
{
   public class FileGetResult: IQueryFileModel
    {
        public long UploadimageDataID { get; set; }
        public byte[] Data { get; set; }
        public string EmailID { get; set; }
        public DateTime CreatedOn { get; set; }
      
    }
}
