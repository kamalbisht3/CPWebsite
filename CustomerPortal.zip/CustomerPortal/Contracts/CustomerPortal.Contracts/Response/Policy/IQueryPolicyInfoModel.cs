﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Policy
{
    public interface IQueryPolicyInfoModel
    {
    }
}
