﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.QuoteHistory
{
    public interface IQueryQuoteHistoryModel
    {
    }
}