﻿using System;

namespace Mena.Apis.CustomerPortal.Contracts.Response.QuoteHistory
{
    public class QuoteHistory : IQueryQuoteHistoryModel
    {
        public Guid CustomerActivity_ID { get; set; }
        public short Brand_ID { get; set; }
        public string CoverType { get; set; }
        public string ResultObject { get; set; }
    }
}
