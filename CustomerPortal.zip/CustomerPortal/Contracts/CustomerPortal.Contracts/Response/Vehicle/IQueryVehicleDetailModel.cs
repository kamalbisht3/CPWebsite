﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Vehicle
{
    public interface IQueryVehicleDetailModel
    {
    }
}
