﻿namespace Mena.Apis.CustomerPortal.Contracts.Response.Vehicle
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class VehicleInfo : IQueryVehicleDetailModel
    {
        public long VehicleMasterID { get; set; }
        public string Modelname { get; set; }
        public string Makename { get; set; }
        public string Platenumber { get; set; }
        //public string ModifiedVersionName { get; set; }

    }
}
