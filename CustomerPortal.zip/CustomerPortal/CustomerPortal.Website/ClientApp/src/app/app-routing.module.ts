import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

const routes: Routes = [

    {
        path: 'dashboard',
        loadChildren: () => import('./dashboard/dashboard.module').then(module => module.dashboardModule)
    },
    {
        path: '',
        loadChildren: () => import('./auth/auth.module').then(module => module.AuthModule)
    },

];

@NgModule({
    imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, enableTracing: false })],
    exports: [RouterModule]
})
export class AppRoutingModule { }
