import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthComponent } from '../auth/auth.component';
import { NoAuthGuard } from '../shared/guards/no-auth-guard.service';
import { loginComponent } from './components/login/login.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';
import { ResolverService } from './resolvers/resolver.service';

const routes: Routes = [
    {
        path: '',
        component: AuthComponent,
        canActivate: [NoAuthGuard],
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'login'
            },
            {
                path: 'login',
                component: loginComponent,
                resolve: { message: ResolverService },
            },
            {
                path: 'forgot',
                component: ForgotpasswordComponent
            }
        ]
    }
];



@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class authRoutingModule { }
