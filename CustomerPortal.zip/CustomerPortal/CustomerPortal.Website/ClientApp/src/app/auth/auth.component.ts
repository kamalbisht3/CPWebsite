import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { InternalizationService } from '../shared/services/internalization.service';
import { CommonLabelHandlerService } from '../shared/services/commonlabel-handler.service';
import { Culture } from '../shared/models/culture';
import { CommonLabelTextConstants } from '../shared/constants/common-label-text';


@Component({
    selector: 'app-auth',
    templateUrl: './auth.component.html',
    styleUrls: ['./auth.component.css']
})
export class AuthComponent extends Culture implements OnInit, OnDestroy {

    constructor(internalizationService: InternalizationService, changeDetection: ChangeDetectorRef, commonLabelHandlerService: CommonLabelHandlerService) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }

    CommonLabelTextConstants = CommonLabelTextConstants;

    ngOnInit() {
        super.cultureInitiallizer();
    }

    ngOnDestroy() {
        super.ngOnDestroy();
    }

}
