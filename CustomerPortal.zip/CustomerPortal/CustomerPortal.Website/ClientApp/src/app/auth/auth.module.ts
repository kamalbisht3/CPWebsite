import { CommonModule } from "@angular/common"
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { HeaderComponent } from './components/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { authRoutingModule } from './auth-routing.module';
import { AuthComponent } from './auth.component';
import { loginComponent } from './components/login/login.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';

import { authEndPoints } from './urlEndPoints/auth-endpoints';
import { END_POINTS, ApiEndpointsService } from '../shared/services/endpoints.service';
import { AuthService } from './services/auth.service';
import { ForgotService } from './services/forgot.service';
import { forgotEndPoints } from './urlEndPoints/forgot-endpoints';

const AUTH_URL = { provide: END_POINTS, multi: true, useValue: authEndPoints };
const FORGOT_URL = { provide: END_POINTS, multi: true, useValue: forgotEndPoints };

@NgModule({
    declarations: [
        AuthComponent,
        HeaderComponent,
        loginComponent,
        ForgotpasswordComponent
    ],
    imports: [
        CommonModule,
        authRoutingModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    providers: [
        ApiEndpointsService, AUTH_URL, AuthService, FORGOT_URL, ForgotService
    ]
})
export class AuthModule { }
