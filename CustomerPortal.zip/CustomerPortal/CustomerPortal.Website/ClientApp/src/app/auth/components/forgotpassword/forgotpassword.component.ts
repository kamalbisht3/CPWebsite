import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmailValidator } from '../../validators/email.validator';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { CommonLabelTextConstants } from '../../../shared/constants/common-label-text';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { ForgotService } from '../../services/forgot.service';
import { Culture } from '../../../shared/models/culture';
import { ForgotLabelTextConstants } from '../../../shared/constants/forgot-label-text';
@Component({
    selector: 'app-forgotpassword',
    templateUrl: './forgotpassword.component.html',
    styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent extends Culture implements OnInit, OnDestroy {
    isSubmitted = false;
    message = '';
    isSent = false;
    ForgotLabelTextConstants = ForgotLabelTextConstants;
    constructor(private router: Router, private forgotService: ForgotService, commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }

    forgotForm = new FormGroup({
        email: new FormControl('', [Validators.required, EmailValidator]),
    });

    ngOnInit() {
        super.cultureInitiallizer();
    }

    //add a get property to make easy to access the form controls on the HTML form
    get formControls() {
        return this.forgotForm.controls;
    }

    ngOnDestroy() {

    }

    forgot() {
        this.isSubmitted = true;
        if (this.forgotForm.invalid) {
            return;
        }

        var forgetMessageText = this.getLabel(CommonLabelTextConstants.CPForgetPasswordMessage);

        this.forgotService.forgotPassword({
            email: this.forgotForm.get('email').value, forgotMessage: forgetMessageText
        }).subscribe((response) => {
            if (response === 1) {
                this.message = 'Success! Password has been sent on your valid emailId.';
            }
            else{
                this.message = 'Invalid email..!';
            }
            this.isSent = true;
        })

    }

    login() {
        this.router.navigateByUrl('/login');
    }

    hasError(controlName, errorName) {
        return this.forgotForm.get(controlName).hasError(errorName) && this.isSubmitted;
    }

}
