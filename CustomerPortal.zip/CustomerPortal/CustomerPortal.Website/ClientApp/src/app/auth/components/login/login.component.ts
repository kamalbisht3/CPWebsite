import { Component, OnInit, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmailValidator } from '../../validators/email.validator';
import { AuthService } from '../../services/auth.service';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { CommonLabelTextConstants } from '../../../shared/constants/common-label-text';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { Culture } from '../../../shared/models/culture';
import { LoginLabelTextConstants } from '../../../shared/constants/login-label-text';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class loginComponent extends Culture implements OnInit, OnDestroy {

    isSubmitted = false;
    error = '';
    LoginLabelTextConstants=LoginLabelTextConstants
    constructor(private router: Router, private authService: AuthService, commonLabelHandlerService: CommonLabelHandlerService,  internalizationService: InternalizationService,  changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }

    loginForm = new FormGroup({
        user: new FormControl('', [Validators.required, EmailValidator]),
        password: new FormControl('', [Validators.required]),
    });


    ngOnInit() {
        super.cultureInitiallizer();
        
        //commonLabelData[CommonLabelTextConstants.CPCahngePassword]['labelValue_' + culture.en]
    }

    ngOnDestroy() {
        
    }

      hasError(controlName, errorName) {
          return this.loginForm.get(controlName).hasError(errorName) && this.isSubmitted;
      }

    //add a get property to make easy to access the form controls on the HTML form
    get formControls()
    {
        return this.loginForm.controls;
    }

  login() {
        this.isSubmitted = true;
        if (this.loginForm.invalid) {
            return;
        }
      this.authService.attemptAuth({ email: this.loginForm.get('user').value, password: this.loginForm.get('password').value }).subscribe((response) => {
        if (response.userAccountStatus === 1)
            this.router.navigateByUrl('/dashboard');
        else
            this.error = response.resultSet;
      })
        
    }

    forgotpassword() {
        this.router.navigateByUrl('/forgot');
    }


    onInputChange(Value: any,name: string): void {
        var errormesseage = this.error.split(' ')[0].trim().toLowerCase();
        if (errormesseage === name) {
            if (Value.target.value.length === 0) {
                this.error = '';
            }
        }
        if (errormesseage === name) {
            if (Value.target.value.length === 0) {
                this.error = '';
            }
        }
    }

    onInputUserChange(Value: any): void {
        var errormesseage = this.error.split(' ')[0].trim().toLowerCase();
        var type = Value.target.type.toLowerCase();
        if (errormesseage === type) {
            if (Value.target.value.length === 0) {
                this.error = '';
            }
        }
    }
}
