export interface credentials {
    email: string;
    password: string;
}
