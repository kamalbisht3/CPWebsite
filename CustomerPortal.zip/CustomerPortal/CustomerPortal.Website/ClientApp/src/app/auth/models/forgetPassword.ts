export interface forgetPassword {
    email: string;
    forgotMessage: string;
}
