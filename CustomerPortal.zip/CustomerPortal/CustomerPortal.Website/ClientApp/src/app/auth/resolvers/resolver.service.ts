import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable, } from 'rxjs';
import { take } from 'rxjs/internal/operators';
import { CommonLabelHandlerService } from '../../shared/services/commonlabel-handler.service';
import { OptionsHandlerService } from '../../shared/services/options-handler.service';

@Injectable({
    providedIn: 'root'
})
export class ResolverService implements Resolve<Observable<boolean>> {
    constructor(private commonLabelHandlerService: CommonLabelHandlerService, optionsHandlerService: OptionsHandlerService) { }

    resolve() {
        return this.commonLabelHandlerService.isDataAvailable.pipe(take(1));
    }
}
