import { Injectable } from '@angular/core';
import { Observable ,  BehaviorSubject ,  ReplaySubject } from 'rxjs';
import { map ,  distinctUntilChanged } from 'rxjs/operators';
import { UserService } from '../../shared/services/user.service';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { User } from '../../shared/models/user.model';
import { credentials} from '../models/credentials'
import { ApiEndpointsService } from '../../shared/services/endpoints.service';


@Injectable()
export class AuthService {
 

  constructor(private httpWrapperService: HttpWrapperService,
    private userService: UserService, private apiEndpointsService: ApiEndpointsService,
  ) {}

 
  setAuth(user: User) {
    // Set current user data into observable
    this.userService.setCurrentUser(user);
    // Set isAuthenticated to true
    this.userService.setAuthentication(true);
  }

  attemptAuth(credentials: credentials): Observable<User> {
    //const route = (type === 'login') ? '/login' : '';
    return this.httpWrapperService.postMapped<serverResponse<User>>(this.apiEndpointsService.endPoints.login, credentials)
      .pipe(map(
        data => {
          if (data && data.status) {
            this.setAuth(data.response);
            return data.response;
          }
          else
            return undefined;
        }
      ));
  }

}

