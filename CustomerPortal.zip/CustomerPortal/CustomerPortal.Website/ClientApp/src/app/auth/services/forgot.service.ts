import { Injectable } from '@angular/core';
import { Observable ,  BehaviorSubject ,  ReplaySubject } from 'rxjs';
import { map ,  distinctUntilChanged } from 'rxjs/operators';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { User } from '../../shared/models/user.model';
import { credentials} from '../models/credentials'
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { forgetPassword } from '../models/forgetPassword';


@Injectable()
export class ForgotService {
 

  constructor(private httpWrapperService: HttpWrapperService,private apiEndpointsService: ApiEndpointsService) {}

    forgotPassword(credentials: forgetPassword): Observable<any> {
      return this.httpWrapperService.postMapped<serverResponse<User>>(this.apiEndpointsService.endPoints.forgot, credentials)
      .pipe(map(
        data => {
          if (data && data.status) {
            return data.response;
          }
          else
            return undefined;
        }
      ));
  }

}

