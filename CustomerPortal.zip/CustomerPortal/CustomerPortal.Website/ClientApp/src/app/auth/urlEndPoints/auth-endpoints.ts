export const authEndPoints = {
    login: 'api/auth/login',
};
