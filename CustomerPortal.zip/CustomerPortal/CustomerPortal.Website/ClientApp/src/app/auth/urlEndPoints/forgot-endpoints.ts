export const forgotEndPoints = {
    forgot: 'api/auth/forgot',
};
