interface EndPoints {
    login: string;
}
