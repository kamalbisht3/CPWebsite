interface EndPoints {
  forgot: string
}
