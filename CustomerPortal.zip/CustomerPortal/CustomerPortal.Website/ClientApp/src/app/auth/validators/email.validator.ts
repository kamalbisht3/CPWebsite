import { AbstractControl, ValidatorFn } from "@angular/forms";

export function EmailValidator(control: AbstractControl) {
    var emailPattern = /^[\w_.]+@[a-zA-Z]+?\.[a-zA-Z]{2,3}$/;
    if (control.value) {
        if (emailPattern.test(control.value.toLowerCase()))
            return null;
    }
    return { 'emailWrongPattern': true };

}
