import { Component, OnInit, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { Culture } from '../shared/models/culture';
import { CommonLabelHandlerService } from '../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../shared/services/internalization.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ConfirmPasswordValidator } from './validators/confirm-password.validation';
import { ChangePasswordService } from './services/changepassword.service';
import { ChangePasswordLabelTextConstants } from '../shared/constants/changepassword-label-text';
import { Router } from '@angular/router';


@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
    styleUrls: ['./changepassword.component.css'],
    //changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChangepasswordComponent extends Culture implements OnInit, OnDestroy{

    isSubmitted = false;
    message: any;
    isSuccess = false;
    constructor(private router: Router,private changePasswordService: ChangePasswordService, commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    ChangePasswordLabelTextConstants = ChangePasswordLabelTextConstants;
    changepasswordForm = new FormGroup({
        newPwd: new FormControl('', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[A-Za-z\d$@$!%*?&].{7,31}')]),
        confirmPwd: new FormControl('', [Validators.required])
    }, {
        validators: ConfirmPasswordValidator
    });


    ngOnInit() {
        super.cultureInitiallizer();
    }


    hasError(controlName, errorName) {
        return this.changepasswordForm.get(controlName).hasError(errorName) && this.isSubmitted;
    }

    ngOnDestroy() {
     
    }

    //add a get property to make easy to access the form controls on the HTML form
    get formControls() {
        return this.changepasswordForm.controls;
    }


    changePassword() {
        this.isSubmitted = true;
        if (this.changepasswordForm.invalid) {
            return;
        }
        if (this.changepasswordForm.get('newPwd').value !== '' && this.changepasswordForm.get('confirmPwd').value !== '') {
            this.changePasswordService.changePassword({ newpassword: this.changepasswordForm.get('newPwd').value, confirmpassword: this.changepasswordForm.get('confirmPwd').value }).subscribe((response) => {
                if (response.status === 1) {

                    this.message = response.resultSet.toString();
                    this.changepasswordForm = new FormGroup({
                        confirmPwd: new FormControl(''),
                        newPwd: new FormControl('')
                    });
                    //this.router.navigateByUrl('dashboard/changepassword');
                } else {
                    this.message = response.resultSet;
                }
                this.isSuccess = true;
            });
        }

    }


}
