import { CommonModule } from "@angular/common"
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { ChangePasswordService } from './services/changepassword.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChangepasswordComponent } from './changepassword.component';
import { ChangePasswordRoutingModule } from './changepassword-routing.module';
import { changepasswordEndPoints } from './urlEndPoints/changepassword-endpoints';
import { END_POINTS, ApiEndpointsService } from '../shared/services/endpoints.service';


const CHANGEPASSWORD_URL = { provide: END_POINTS, multi: true, useValue: changepasswordEndPoints };

@NgModule({
  declarations: [
        ChangepasswordComponent
  ],
    imports: [
        CommonModule,
        SharedModule,
        ChangePasswordRoutingModule,
        FormsModule,
        ReactiveFormsModule,
  ],
  providers: [
      ApiEndpointsService, CHANGEPASSWORD_URL, ChangePasswordService
  ]
})
export class ChangePasswordModule { }
