export interface changepassword {
    newpassword: string;
    confirmpassword: string;
}
