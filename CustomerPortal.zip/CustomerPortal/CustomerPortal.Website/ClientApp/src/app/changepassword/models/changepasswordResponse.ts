export interface changepasswordResponse {
    status: number;
    resultSet: string;
}
