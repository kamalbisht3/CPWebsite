import { Injectable } from '@angular/core';
import { Observable ,  BehaviorSubject ,  ReplaySubject } from 'rxjs';
import { map ,  distinctUntilChanged } from 'rxjs/operators';
import { UserService } from '../../shared/services/user.service';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { User } from '../../shared/models/user.model';
import { changepassword } from '../models/changepassword'
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { changepasswordResponse } from '../models/changepasswordResponse';


@Injectable()
export class ChangePasswordService {
 

  constructor(private httpWrapperService: HttpWrapperService,
    private apiEndpointsService: ApiEndpointsService,
  ) {}



    changePassword(changepassword: changepassword): Observable<changepasswordResponse> {
        return this.httpWrapperService.postMapped<serverResponse<changepasswordResponse>>(this.apiEndpointsService.endPoints.changepassword, changepassword)
      .pipe(map(
        data => {
          if (data && data.status) {
            return data.response;
          }
          else
            return undefined;
        }
      ));
  }

}

