export const changepasswordEndPoints = {
    changepassword: 'api/auth/ChangePassword',
};
