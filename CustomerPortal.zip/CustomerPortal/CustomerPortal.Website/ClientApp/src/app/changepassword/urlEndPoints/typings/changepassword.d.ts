interface EndPoints {
  changepassword: string
}
