import { AbstractControl, ValidatorFn } from "@angular/forms";

export function ConfirmPasswordValidator(control: AbstractControl) {
    let pass = control.get('newPwd').value;
    let confirmPass = control.get('confirmPwd').value;

    if (confirmPass === '') {
        control.get('confirmPwd').setErrors({ 'required': true });
        return null;
    }
    else control.get('confirmPwd').setErrors(null);
    pass === confirmPass ? control.get('confirmPwd').setErrors(null) : control.get('confirmPwd').setErrors({ 'passwordNotMatched': true });
    return null;
}
