import { Component, OnInit } from '@angular/core';
import { RoutesData } from '../../constants/route.constant';
import { RouteInfo } from '../../models/route-info';
import { UserService } from '../../../shared/services/user.service';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { SideBarLabelTextConstants } from '../../../shared/constants/sidebar-label-text';
import { Router } from '@angular/router';

declare const $: any;


@Component({
  selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
    menuItems: RouteInfo[];
    commonLabel: any;
    sidemenu: any;
    //SideBarLabelTextConstants = SideBarLabelTextConstants;
    constructor(private userService: UserService, private commonLabelHandlerService: CommonLabelHandlerService, private router: Router) { }

    ngOnInit() {
        //this.commonLabel = this.commonLabelHandlerService.allCommonLabel;
        //this.sidemenu = SideBarLabelTextConstants.filter(item => item.path === this.commonLabel['LabelPath']);
    this.menuItems = RoutesData.filter(menuItem => menuItem);
  }
  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
    };

    logout() {
        this.userService.logoutUser().subscribe(obj => {
            this.userService.purgeAuth()
            this.router.navigate(['login']);
        });
    }
}
