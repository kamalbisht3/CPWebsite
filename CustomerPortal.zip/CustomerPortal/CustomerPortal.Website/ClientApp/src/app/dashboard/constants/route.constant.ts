import { RouteInfo } from '../models/route-info';

export const RoutesData: RouteInfo[] = [
    { path: '/dashboard', title: 'Home', icon: 'pe-7s-graph', class: '' },
    { path: '/dashboard/policies', title: 'Policies', icon: 'pe-7s-user', class: '' },
    { path: '/dashboard/personaldetail', title: 'Personal Details', icon: 'pe-7s-note2', class: '' },
    { path: '/dashboard/vehicle', title: 'Vehicle', icon: 'pe-7s-news-paper', class: '' },
    { path: '/dashboard/quote-history', title: 'Quote History', icon: 'pe-7s-science', class: '' },
    { path: '/dashboard/changepassword', title: 'ChangePassword', icon: 'pe-7s-graph', class: '' },
];

