import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { DashboardAuthResolver } from './resolvers/dashboard-auth-resolver.service';
import { AuthGuard } from '../shared/guards/auth-guard.service';
import { CustomerInfoResolver } from './resolvers/customerinfo-resolver.service';
import { ResolverService } from '../auth/resolvers/resolver.service';


const routes: Routes = [
    {
        path: '',
        //pathMatch: 'full',
        component: DashboardComponent,
        resolve: {
            isAuthenticated: DashboardAuthResolver, message: ResolverService,
            dataAvailable: CustomerInfoResolver
        },
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                loadChildren: () => import('../home/home.module').then(module => module.HomeModule),
                //pathMatch: 'full',
            },
            {
                path: 'changepassword',
                loadChildren: () => import('../changepassword/changepassword.module').then(module => module.ChangePasswordModule),
            },
            {
                path: 'personaldetail',
                loadChildren: () => import('../personaldetail/personaldetail.module').then(module => module.PersonalDetailModule)
            },
            {
                path: 'policies',
                loadChildren: () => import('../policy/policy.module').then(module => module.PolicyModule)
            },
            {
                path: 'quote-history',
                loadChildren: () => import('../quote-history/quote-history.module').then(module => module.QuoteHistoryModule)
            },
            {
                path: 'vehicle',
                loadChildren: () => import('../vehicle/vehicle.module').then(module => module.VehicleModule)
            },
        ]
    },

]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class dashboardRoutingModule { }
