import { CommonModule } from "@angular/common"
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { dashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { HeaderComponent } from './components/header/header.component';

import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { SignoutComponent } from './components/signout/signout.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
//import { HomeModule } from '../home/home.module';
//import { ChangePasswordModule } from '../changepassword/changepassword.module';
//import { PersonalDetailModule } from '../personaldetail/personaldetail.module';



@NgModule({
    declarations: [
        DashboardComponent,
        HeaderComponent,
        NavbarComponent, FooterComponent, SignoutComponent, SidebarComponent
    ],
    imports: [
        CommonModule,
        dashboardRoutingModule,
        SharedModule
  ],
  providers: [

    ]
})
export class dashboardModule { }
