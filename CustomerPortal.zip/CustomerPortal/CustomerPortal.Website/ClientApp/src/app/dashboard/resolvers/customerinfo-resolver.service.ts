import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomerDataAvailabilty } from './../../shared/services/cutomerdata-availability.service';
import { take } from 'rxjs/operators';
import { PersonalDetailsHandlerService } from '../../shared/services/personaldetails-handler.service';
import { PolicyDataHandlerService } from '../../shared/services/policy-handler.service';
import { VehicleDataHandlerService } from '../../shared/services/vehicledata-handler.service';
import { QuoteHistoryHandlerService } from '../../shared/services/quote-history-handler.service';

@Injectable({
    providedIn: 'root'
})
export class CustomerInfoResolver implements Resolve<boolean> {
    constructor(private customerDataAvailabilty: CustomerDataAvailabilty, personalDetailsHandlerService: PersonalDetailsHandlerService, policyDataHandlerService: PolicyDataHandlerService, quoteHistoryHandlerService: QuoteHistoryHandlerService, vehicleDataHandlerService: VehicleDataHandlerService) { }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
        return this.customerDataAvailabilty.isCustomerDataAvailable.pipe(take(4));
    }
}
