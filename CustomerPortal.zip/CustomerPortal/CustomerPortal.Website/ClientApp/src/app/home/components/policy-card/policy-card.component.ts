import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { Culture } from '../../../shared/models/culture';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { PolicyCardLabelTextConstants } from '../../../shared/constants/policycard-label-text';
import { OptionsHandlerService } from '../../../shared/services/options-handler.service';
import { PolicyCardQuestionEnum } from '../../enums/questionpolicycard.enum';

@Component({
    selector: 'app-policy-card',
    templateUrl: './policy-card.component.html',
    styleUrls: ['./policy-card.component.css']
})
export class PolicyCardComponent extends Culture implements OnInit {

    @Input() policyCardData: any;
    policyHolderInfo: any;
    driverInfo: any;
    vehicleInfo: any;
    quotationInfo: any;
    constructor(commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef, private optionsHandlerService: OptionsHandlerService ) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    PolicyCardLabelTextConstants = PolicyCardLabelTextConstants;
    PolicyCardQuestionEnum = PolicyCardQuestionEnum;
    ngOnInit() {
        super.cultureInitiallizer();
        this.getDetails();
    }

    getDetails() {
        var data = JSON.parse(this.policyCardData.risk).ContractType;
        this.vehicleInfo = data.Vehicle;
        this.quotationInfo = data.QuotationInfo;
        this.policyHolderInfo = {
            firstNameEnglish: data.PolicyHolderDetails.FirstNameEnglish,
            lastNameEnglish: data.PolicyHolderDetails.LastNameEnglish,
            firstNameArabic: data.PolicyHolderDetails.FirstNameArabic,
            lastNameArabic: data.PolicyHolderDetails.LastNameArabic,
            birthDateCulture: data.PolicyHolderDetails.BirthDateCulture
        };

    }

    getOption(questionId: number, lookupId: number) {
        return this.optionsHandlerService.GetOptionValue(questionId, lookupId, this.currentCulture);
    }
}
