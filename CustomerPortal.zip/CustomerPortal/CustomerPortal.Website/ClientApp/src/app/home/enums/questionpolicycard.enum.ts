export enum PolicyCardQuestionEnum {
    Coverage= 7,
}
