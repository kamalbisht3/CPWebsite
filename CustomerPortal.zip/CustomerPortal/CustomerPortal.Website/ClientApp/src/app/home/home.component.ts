import { Component, OnInit } from '@angular/core';
import { SliderService } from '../shared/services/slider.service';
import { PolicyDataHandlerService } from '../shared/services/policy-handler.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    policyInfoArray: any[] = [];
    
    constructor(private sliderService: SliderService, private policyDataHandlerService: PolicyDataHandlerService) { }

    ngOnInit() {
        this.sliderService.current = 0;
        this.sliderService.prev = -1;
        this.policyInfoArray = this.policyDataHandlerService.GetPolicyInfo();
    }

}
