export enum QuestionEnum {
    Education = 13,
    Occupation = 14,
    MaritalStatus = 16,
    LicenseType = 8,
    Relationship = 26,
    DrivingPercentage = 22,
    Coverage= 7,

}
