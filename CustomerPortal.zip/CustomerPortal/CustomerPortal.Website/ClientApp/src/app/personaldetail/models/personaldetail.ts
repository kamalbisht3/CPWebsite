export interface personaldetail {
    newpassword: string;
    confirmpassword: string;
}
