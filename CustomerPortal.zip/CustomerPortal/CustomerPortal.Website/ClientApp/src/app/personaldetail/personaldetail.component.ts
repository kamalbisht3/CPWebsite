import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Culture } from '../shared/models/culture';
import { Router } from '@angular/router';
import { CommonLabelHandlerService } from '../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../shared/services/internalization.service';
import { PersonalDetailLabelTextConstants } from '../shared/constants/personaldetail-label-text';
import { OptionsHandlerService } from '../shared/services/options-handler.service';
import { QuestionEnum } from './enums/question.enum';
import { riskType } from '../shared/models/Risk/riskType';
import { PersonalDetailsHandlerService } from '../shared/services/personaldetails-handler.service';

@Component({
    selector: 'app-personaldetail',
    templateUrl: './personaldetail.component.html',
    styleUrls: ['./personaldetail.component.css']
})
export class PersonaldetailComponent extends Culture implements OnInit, OnDestroy {
    personalDetailRisk: riskType;
    QuestionEnum = QuestionEnum;
    //drivres: any;

    constructor(private router: Router, private personalDetailsHandlerService: PersonalDetailsHandlerService, commonLabelHandlerService: CommonLabelHandlerService, private optionsHandlerService: OptionsHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    PersonalDetailLabelTextConstants = PersonalDetailLabelTextConstants;

    ngOnInit() {
        super.cultureInitiallizer();
        this.personalDetailRisk = this.personalDetailsHandlerService.GetPersonalInfo();
    }

    getOption(questionId: number, lookupId: number) {
        return this.optionsHandlerService.GetOptionValue(questionId, lookupId, this.currentCulture);
    }



}
