import { CommonModule } from "@angular/common"
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { END_POINTS, ApiEndpointsService } from '../shared/services/endpoints.service';
import { PersonaldetailComponent } from './personaldetail.component';
import { personaldetailRoutingModule } from './personaldetail-routing.module';

@NgModule({
    declarations: [
        PersonaldetailComponent
    ],
    imports: [
        CommonModule,
        personaldetailRoutingModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    providers: [
        ApiEndpointsService
    ]
})
export class PersonalDetailModule { }
