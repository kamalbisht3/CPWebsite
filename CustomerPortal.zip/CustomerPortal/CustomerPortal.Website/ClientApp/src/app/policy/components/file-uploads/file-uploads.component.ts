import { Component, OnInit, OnDestroy,ViewChild, ElementRef } from '@angular/core';
import { UploadService } from '../../services/upload.service';
import { Extensions } from '../../constants/upload-extensions.constant';
import { UploadHandlerService } from '../../services/upload-handler.service';
import { GetUploadedFileResponse } from '../../models/get-uploaded-file-response';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-policy-file-uploads',
    templateUrl: './file-uploads.component.html',
    styleUrls: ['./file-uploads.component.css']
})
export class FileUploadsComponent implements OnInit, OnDestroy {
   
  @ViewChild('fileElement', { static: false }) fileElementRef: ElementRef;
 
  uploadDatainbytes: GetUploadedFileResponse[];
    Extensions = Extensions;
    extensions: any;
    error: string;
  filesData: {id:number, image: string}[] = [];
  dataLoadingComplete: boolean = false;
 
  constructor(private uploadHandlerService: UploadHandlerService)
  {
   
  }

  ngOnInit()
  {
    this.dataLoadingComplete = false;
    this.extensions = Object.keys(Extensions);
    debugger;
    this.ShowUploadedFiles();
    
  }

  dataAvailableSubscription: Subscription;

  ShowUploadedFiles()
  {    
    this.dataAvailableSubscription = this.uploadHandlerService.isDataAvailable.subscribe(
       (result) =>
      {
        if (result) {
          this.uploadDatainbytes = this.uploadHandlerService.GetImages();
          this.dataLoadingComplete = true;
          debugger;
          this.filesData = [];
           for (let ele of this.uploadDatainbytes) {
            this.filesData.push({ image: "data:image/jpeg;base64," + ele.data, id: ele.uploadimageDataID });
          }
         
         
        }
       }
    );    
  }

  arrayBufferToBase64(buffer:any):string {
  var binary = '';
  var bytes = new Uint8Array(buffer);
  var len = bytes.byteLength;
  for (var i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}


    handleFileInput(files: FileList) {
        if (files) {
            if (this.validateExtensions(files.item(0).name)) {
                //if (!this.checkForDuplicacy(files.item(0).name)) {
                this.error = '';
                //this.fileToUpload.push(files.item(0));
                //  this.names.push(files.item(0).name);
                var filesAmount = files.length;
                //for (let i = 0; i < filesAmount; i++) {
                //  var reader = new FileReader();

                //  reader.onload = (event: any) => {
                //    this.urls.push(event.target.result);
                //    this.filesData.push({ image: event.target.result, id: ele.uploadimageDataID });
                //  }
                //  reader.readAsDataURL(files[i]);


                //}

                this.onSubmit(files.item(0));
                //}
                //else {
                //  this.error = 'File already exists!!!';
                //}
            }
            else {
                this.error = "File format not supported.";
            }
        }
    }

  onSubmit(file: File) {
    if (file && file.size > 0) {
      //var filesAmount = event.target.files.length;
      const formData = new FormData();

      // this.fileToUpload.forEach((value, index) => {
      formData.append('file', file);
      console.log(formData.get('file'));
      //});


      this.uploadHandlerService.uploadImages(formData);
    }
  }

    //enable multiple file upload at a time 


    validateExtensions(name) {
        var isValid = false;
        this.extensions.forEach(k => {
            if (name.indexOf(k) > -1)
                isValid = true;
        });
        return isValid;
    }

  //checkForDuplicacy(name) {
  //  return (this.filesData.find(t=>t.));
  //}

    removeImage(index, id) {       

      if (confirm("Are you sure to delete?")) {
        this.uploadHandlerService.removeImage(id);
        this.filesData.splice(index, 1);
      
        if (this.filesData.length == 0) {
          this.fileElementRef.nativeElement.value = "";
        }
        
       

      }
        //this.fileToUpload.splice(index, 1);
  }

  ngOnDestroy(): void {
    if (this.dataAvailableSubscription)
      this.dataAvailableSubscription.unsubscribe();
  }
}
