import { Component, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { Culture } from '../../../shared/models/culture';
import { Router } from '@angular/router';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { OptionsHandlerService } from '../../../shared/services/options-handler.service';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { PersonalDetailLabelTextConstants } from '../../../shared/constants/personaldetail-label-text';
import { PersonalDetailsHandlerService } from '../../../shared/services/personaldetails-handler.service';
import { riskType } from '../../../shared/models/Risk/riskType';

@Component({
    selector: 'app-policy-personal-info',
    templateUrl: './personal-info.component.html',
    styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent extends Culture implements OnInit {
    @Input() personalInfo: any;
    constructor(commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    PersonalDetailLabelTextConstants = PersonalDetailLabelTextConstants;

    ngOnInit() {
        super.cultureInitiallizer();
    }
}
