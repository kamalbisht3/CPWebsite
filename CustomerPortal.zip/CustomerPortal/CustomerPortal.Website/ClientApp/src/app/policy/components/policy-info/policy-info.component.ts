import { Component, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { Culture } from '../../../shared/models/culture';
import { PolicyDetailLabelTextConstants } from '../../../shared/constants/policy-label-text';
import { OptionsHandlerService } from '../../../shared/services/options-handler.service';
import { PolicyQuestionEnum } from '../../enums/questionpolicy.enum';



@Component({
    selector: 'app-policy-info',
    templateUrl: './policy-info.component.html',
    styleUrls: ['./policy-info.component.css']
})
export class PolicyInfoComponent extends Culture implements OnInit {
    @Input() policyInfo: any;
    @Input() policyInfoCompleteData: any;
    @Input() vehicleInfo: any;
    PolicyQuestionEnum = PolicyQuestionEnum;
    constructor(commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef, private optionsHandlerService: OptionsHandlerService, ) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    PolicyDetailLabelTextConstants = PolicyDetailLabelTextConstants;

    ngOnInit() {
        super.cultureInitiallizer();
    }

    getOption(questionId: number, lookupId: number) {
        return this.optionsHandlerService.GetOptionValue(questionId, lookupId, this.currentCulture);
    }
}
