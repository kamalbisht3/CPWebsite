import { Component, OnInit } from '@angular/core';
import { SliderService } from '../../../shared/services/slider.service';
import { PolicyDataHandlerService } from '../../../shared/services/policy-handler.service';

@Component({
    selector: 'app-policy-policy-slider',
    templateUrl: './policy-slider.component.html',
    styleUrls: ['./policy-slider.component.css']
})
export class PolicySliderComponent implements OnInit {
    policyInfoArray: any[] = [];
    policyHolderInfo: any[] = [];
    driverInfo: any[] = [];
    vehicleInfo: any[] = [];
    policyInfo: any[] = [];

    constructor(private sliderService: SliderService, private policyDataHandlerService: PolicyDataHandlerService) { }

    ngOnInit() {
        this.sliderService.current = 0;
        this.sliderService.prev = -1;
        this.policyInfoArray = this.policyDataHandlerService.GetPolicyInfo();
        this.getDetails();
    }

    getDetails() {
        this.policyInfoArray.forEach(data => {
            var risk = JSON.parse(data.risk).ContractType;
            this.vehicleInfo.push(risk.Vehicle);
            this.policyInfo.push(risk.QuotationInfo);
            this.policyHolderInfo.push({
                firstNameEnglish: risk.PolicyHolderDetails.FirstNameEnglish,
                lastNameEnglish: risk.PolicyHolderDetails.LastNameEnglish,
                firstNameArabic: risk.PolicyHolderDetails.FirstNameArabic,
                lastNameArabic: risk.PolicyHolderDetails.LastNameArabic,
                birthDateCulture: risk.PolicyHolderDetails.BirthDateCulture});
            if (risk.Drivers.length > 0) {
                var driversDetail = [];
                risk.Drivers.forEach(driver => {
                    driversDetail.push({
                        firstNameEnglish: driver.FirstNameEnglish,
                        lastNameEnglish: driver.LastNameEnglish,
                        firstNameArabic: driver.FirstNameArabic,
                        lastNameArabic: driver.LastNameArabic,
                        birthDateCulture: driver.BirthDateCulture
                    });
                });
                this.driverInfo.push(driversDetail);
            }
        })
    }
}
