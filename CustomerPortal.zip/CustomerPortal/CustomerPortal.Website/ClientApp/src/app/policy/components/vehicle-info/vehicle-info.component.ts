import { Component, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { Culture } from '../../../shared/models/culture';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { VehicleDetailLabelTextConstants } from '../../../shared/constants/vehicle-label-text';

@Component({
    selector: 'app-policy-vehicle-info',
    templateUrl: './vehicle-info.component.html',
    styleUrls: ['./vehicle-info.component.css']
})
export class VehicleInfoComponent extends Culture  implements OnInit {
    @Input() vehicleInfo: any;
    constructor(commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    VehicleDetailLabelTextConstants = VehicleDetailLabelTextConstants;

    ngOnInit() {
        super.cultureInitiallizer();
    }
}
