export const Extensions = {
    pdf: 'pdf',
    jpg: 'jpg',
    png: 'png',
    jpeg: 'jpeg'
}
