export enum PolicyQuestionEnum {
    Coverage= 7,
}
