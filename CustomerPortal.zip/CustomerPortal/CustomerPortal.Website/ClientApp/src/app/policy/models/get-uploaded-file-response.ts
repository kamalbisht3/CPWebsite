export interface GetUploadedFileResponse {
  uploadimageDataID: number,
  data: any;
}
