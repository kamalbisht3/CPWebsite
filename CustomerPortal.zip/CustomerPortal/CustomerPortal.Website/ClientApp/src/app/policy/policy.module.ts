import { CommonModule } from "@angular/common"
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { PolicyComponent } from './policy.component';
import { PolicyRoutingModule } from './policy-routing.module';
import { VehicleInfoComponent } from './components/vehicle-info/vehicle-info.component';
import { PolicyInfoComponent } from './components/policy-info/policy-info.component';
import { PersonalInfoComponent } from './components/personal-info/personal-info.component';
import { FileUploadsComponent } from './components/file-uploads/file-uploads.component';
import { UploadService } from './services/upload.service';
import { PolicySliderComponent } from './components/policy-slider/policy-slider.component';
import { UploadHandlerService } from './services/upload-handler.service';

@NgModule({
    declarations: [
        PolicyComponent,
        VehicleInfoComponent,
        PolicyInfoComponent,
        PersonalInfoComponent,
        FileUploadsComponent,
        PolicySliderComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        PolicyRoutingModule
    ],
    providers: [
      UploadService,
      UploadHandlerService
     ]
})
export class PolicyModule { }
