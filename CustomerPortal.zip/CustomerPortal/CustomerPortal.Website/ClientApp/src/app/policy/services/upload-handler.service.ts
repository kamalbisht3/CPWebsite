import { Injectable } from '@angular/core';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { UploadService} from './upload.service';
import {  BehaviorSubject, Observable } from 'rxjs';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { GetUploadedFileResponse } from '../models/get-uploaded-file-response';
import { serverResponse } from '../../shared/models/server-response';
import { map } from 'rxjs/operators';

@Injectable()
export class UploadHandlerService {
  uploadData: GetUploadedFileResponse[];

  private isDataAvailableSubject = new BehaviorSubject<boolean>(false);
  public isDataAvailable = this.isDataAvailableSubject.asObservable();

  public ids: number[] = [];

  constructor(private uploadService: UploadService, private memoryStorageService: MemoryStorageService, private http: HttpWrapperService) {
    this.uploadData = this.GetImages();
    if (this.uploadData == null || this.uploadData.length == 0) {
      this.refreshImages();
    }
  }

  private getImageObservable = this.uploadService.GetUploadedFiles();

  private GetLatestImages() {
    this.getImageObservable.subscribe(() => {
     this.uploadData = this.GetImages();

      this.isDataAvailableSubject.next(true);
    });
  }

  GetImages(): GetUploadedFileResponse[] {
    if (this.uploadData == null || this.uploadData.length==0) {
      this.uploadData = this.memoryStorageService.get(memoryStorageKey.uploadedFiles);
      if (!this.uploadData)
        this.uploadData = [];
    }
    return this.uploadData;
  }
  
  refreshImages() {
    this.isDataAvailableSubject.next(false);
    this.uploadData = [];
    this.GetLatestImages();
  }

  removeImage(index: number) {
    this.uploadService.delete(index).subscribe((result: any) => {
      if (result.status) {
        this.refreshImages();
      }
    });
  }

  uploadImages(file: FormData): void {
     this.uploadService.upload(file).subscribe((result: any) => {
      if (result.status) {
        this.refreshImages();
        return result;
      }
    });
  }
}
