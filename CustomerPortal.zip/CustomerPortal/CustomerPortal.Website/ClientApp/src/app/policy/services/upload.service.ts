import { Injectable } from '@angular/core';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { Observable } from 'rxjs';
import { serverResponse } from '../../shared/models/server-response';
import { map } from 'rxjs/operators';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { GetUploadedFileResponse } from '../models/get-uploaded-file-response';

@Injectable()
export class UploadService {

    constructor(private http: HttpWrapperService, private apiEndpointsService: ApiEndpointsService, private memoryStorageService: MemoryStorageService) { }

    upload(file: FormData): Observable<serverResponse<string>> {
        debugger;
        return this.http.postMapped("/api/File/upload", file);
    }

    delete(id: number): Observable<serverResponse<string>> {
        debugger;
        return this.http.postMapped("/api/File/deleteImage", { ImageId: id });
    }

    GetUploadedFiles(): Observable<serverResponse<GetUploadedFileResponse[]>> {
        return this.http.get('/api/File/getUploadedImage')
            .pipe(map((result: any) => {
                if (result.status)
                    this.memoryStorageService.set(memoryStorageKey.uploadedFiles, result.response)
                return result;
            },
                (error) => { console.error(error.message); }));
    }
}

