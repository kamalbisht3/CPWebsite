import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { QuoteHistoryLabelTextConstants } from '../../../shared/constants/quotehistory-label-text';
import { Culture } from '../../../shared/models/culture';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../../../shared/services/internalization.service';

@Component({
  selector: 'app-landing-button',
  templateUrl: './landing-button.component.html',
  styleUrls: ['./landing-button.component.css']
})
export class LandingButtonComponent extends Culture implements OnInit {

    constructor(commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    QuoteHistoryLabelTextConstants = QuoteHistoryLabelTextConstants;
    ngOnInit() {
        super.cultureInitiallizer();
  }

}
