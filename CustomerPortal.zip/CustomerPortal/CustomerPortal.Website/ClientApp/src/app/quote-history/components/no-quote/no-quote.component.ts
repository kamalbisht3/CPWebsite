import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-quote',
  templateUrl: './no-quote.component.html',
  styleUrls: ['./no-quote.component.css']
})
export class NoQuoteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
