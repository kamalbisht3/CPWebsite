import { Component, OnInit } from '@angular/core';
import { QuoteHistoryResponse } from '../../../shared/models/quotehistoryresponse';
import { QuoteHistoryHandlerService } from '../../../shared/services/quote-history-handler.service';
import { PolicyDataHandlerService } from '../../../shared/services/policy-handler.service';

@Component({
    selector: 'app-quote-list',
    templateUrl: './quote-list.component.html',
    styleUrls: ['./quote-list.component.css']
})
export class QuoteListComponent implements OnInit {

    QuoteList: QuoteHistoryResponse[];
    policyInfoArray: any[] = [];
    vehicleInfo: any[] = [];
    constructor(private quoteHistoryHandlerService: QuoteHistoryHandlerService, private policyDataHandlerService: PolicyDataHandlerService) { }

    ngOnInit() {
        this.QuoteList = this.quoteHistoryHandlerService.GetVehicleInfo();
        this.policyInfoArray = this.policyDataHandlerService.GetPolicyInfo();
        this.getDetails();
    }

    getDetails() {
        this.policyInfoArray.forEach(data => {
            var risk = JSON.parse(data.risk).ContractType;
            this.vehicleInfo.push(risk.Vehicle);
        });
    }

}
