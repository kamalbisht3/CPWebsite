import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'app-quote-logo',
    templateUrl: './quote-logo.component.html',
    styleUrls: ['./quote-logo.component.css']
})
export class QuoteLogoComponent implements OnInit {

    @Input() logoUrl = '';

    constructor() { }

    ngOnInit() {
    }

}
