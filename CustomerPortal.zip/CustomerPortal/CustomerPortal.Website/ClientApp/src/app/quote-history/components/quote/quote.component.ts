import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { QuoteHistoryResponse } from '../../../shared/models/quotehistoryresponse';
import { Culture } from '../../../shared/models/culture';
import { CommonLabelHandlerService } from '../../../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { VehicleDetailLabelTextConstants } from '../../../shared/constants/vehicle-label-text';

@Component({
    selector: 'app-quote',
    templateUrl: './quote.component.html',
    styleUrls: ['./quote.component.css']
})
export class QuoteComponent extends Culture implements OnInit {

    @Input() quoteData: QuoteHistoryResponse;
    @Input() vehicleData: any;
    quotes: any;

    constructor(commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    VehicleDetailLabelTextConstants = VehicleDetailLabelTextConstants;
    ngOnInit() {
        super.cultureInitiallizer();
        this.quotes = JSON.parse(this.quoteData.resultObject);
    }
}
