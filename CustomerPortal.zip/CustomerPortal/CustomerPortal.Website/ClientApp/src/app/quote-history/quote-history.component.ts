import { Component, OnInit } from '@angular/core';
import { QuoteHistoryHandlerService } from './../shared/services/quote-history-handler.service';

@Component({
    selector: 'app-quote-history',
    templateUrl: './quote-history.component.html',
    styleUrls: ['./quote-history.component.css']
})
export class QuoteHistoryComponent implements OnInit {

    constructor(private QuoteHistoryHandlerService: QuoteHistoryHandlerService) { }

    ngOnInit() { }

}
