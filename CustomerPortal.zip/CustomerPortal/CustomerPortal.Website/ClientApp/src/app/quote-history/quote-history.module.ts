import { CommonModule } from "@angular/common"
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { END_POINTS, ApiEndpointsService } from '../shared/services/endpoints.service';
import { QuoteHistoryComponent } from './quote-history.component';
import { QuoteHistoryRoutingModule } from './quote-routing.module';
import { QuoteListComponent } from './components/quote-list/quote-list.component';
import { QuoteComponent } from './components/quote/quote.component';
import { QuoteLogoComponent } from './components/quote-logo/quote-logo.component';
import { LandingButtonComponent } from './components/landing-button/landing-button.component';
import { NoQuoteComponent } from './components/no-quote/no-quote.component';

//const QuoteHistory_URL = { provide: END_POINTS, multi: true, useValue: quoteHistoryEndPoints };
//const FORGOT_URL = { provide: END_POINTS, multi: true, useValue: forgotEndPoints };

@NgModule({
    declarations: [
        QuoteHistoryComponent,
        QuoteListComponent,
        QuoteComponent,
        QuoteLogoComponent,
        LandingButtonComponent,
        NoQuoteComponent
    ],
    imports: [
        SharedModule,
        QuoteHistoryRoutingModule,
        CommonModule
    ],
    providers: [
        ApiEndpointsService
    ]
})
export class QuoteHistoryModule { }
