export const quoteHistoryEndPoints = {
    quoteHistory: 'api/quotehistory/details',
};
