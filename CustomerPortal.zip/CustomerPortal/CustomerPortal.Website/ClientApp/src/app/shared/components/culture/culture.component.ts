import { Component, OnInit, Input } from '@angular/core';
import { InternalizationService } from '../../../shared/services/internalization.service';
import { culture } from '../../../shared/enums/culture.enum';

@Component({
    selector: 'app-cuture-control',
    templateUrl: './culture.component.html',
    styleUrls: ['./culture.component.css']
})
export class cutureControlComponent implements OnInit {

    public cultureText: string;
    @Input() language: any;

    constructor(private internalizationService: InternalizationService) { }

    ngOnInit() {
        this.updateCulture();
    }

    public changeCulture() {

        if (this.internalizationService.currentCulture == culture.en) {
            this.internalizationService.changeLanguage(culture.ar);
            //document.getElementById('main-container').style.cssFloat = 'right';
        }
        else {
            this.internalizationService.changeLanguage(culture.en);
            //document.getElementById('main-container').style.cssFloat = null;
        }

        this.updateCulture();
        //  window.location.reload();        
    }

    private updateCulture() {

        var currentCulture = this.internalizationService.getCurrentLocale();
        //if (this.internalizationService.currentCulture === culture.en) {      
        //this.riskHandlerService.riskType.selectedCulture = culture.en;
        //} else {
        //    this.riskHandlerService.riskType.selectedCulture = culture.ar;
        //}

        if (currentCulture == "en-us") {

            document.documentElement.dir = 'ltr';
            this.cultureText = this.language['labelValue_ar'];
        }
        else {
            document.documentElement.dir = 'rtl';
            this.cultureText = this.language['labelValue_en'];
        }
    }
}
