import { Component, Input } from '@angular/core';
import { SliderService } from '../../services/slider.service';

@Component({
    selector: 'app-slider-panel',
    templateUrl: './slider-panel.component.html',
    styleUrls: ['./slider-panel.component.css'],

})
export class SliderPanelComponent {
    @Input() arrayLength: number;
    constructor(private sliderService: SliderService) { }
}
