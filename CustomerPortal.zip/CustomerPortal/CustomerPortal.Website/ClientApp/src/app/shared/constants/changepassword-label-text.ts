export const ChangePasswordLabelTextConstants = {
    CPChangePasswordConfirmPassword: "CP/ChangePassword/ConfirmPassword",
    CPChangePasswordNewpassword: "CP/ChangePassword/Newpassword",
    CPCahngePassword: "CP/CahngePassword",
};
