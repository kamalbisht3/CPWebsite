﻿export const errorTypes = {
    DateExceedsDaysWeeksMonths: "DateExceedsXdays/weeks/months",
    Dateoftodayisselected: "Dateoftodayisselected",
    Ifnodatafilledafterselectingyes: "Ifnodatafilledafterselectingyes",
    Ifnotmatchwithpreviouspassword: "Ifnotmatchwithpreviouspassword",
    ifwrongcodeentered: "ifwrongcodeentered",
    Invalid: "Invalid",
    InvalidIDfilled: "InvalidIDfilled",
    Nodatafilled: "Nodatafilled",
    Noselection: "Noselection",
    Notanemailformat: "Notanemailformat",
    Notatelephoneformat: "Notatelephoneformat",
    Notavalidpassword: "Notavalidpassword",
    Parentrequired: "Parentrequired",
};

