export const ForgotLabelTextConstants = {
    CPForgetPassword: "CP/ForgetPassword",
    CPEmail: "CP/Email",
    CPSend: "CP/Send",
    CPLogin: "CP/Login",
    CPEmailErrormessage: "CP/Email/Errormessage"
};
