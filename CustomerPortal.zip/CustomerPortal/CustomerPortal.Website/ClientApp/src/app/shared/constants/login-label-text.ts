export const LoginLabelTextConstants = {
    CPForgetPassword: "CP/ForgetPassword",
    CPLogin: "CP/Login",
    CPPassword: "CP/Password",
    CPUserID: "CP/UserID",
    CPPasswordErrorMessage: "CP/Password/ErrorMessage",
    CPUserIDErrorMessage: "CP/UserID/ErrorMessage",
    CPEmailErrormessage:"CP/Email/Errormessage"
};
