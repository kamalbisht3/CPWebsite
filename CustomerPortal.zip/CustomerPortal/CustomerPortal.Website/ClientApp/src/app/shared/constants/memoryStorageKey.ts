export const memoryStorageKey = {
    //SessionData: 'SessionInfo',
    //brands: 'brands',
    //getbranddetails: 'getbranddetails',
    //getquotepageprice: 'getquotepageprice',
    //lookupCommonLabels: 'lookupCommonLabels',
    //questionErrorMessage: 'QuestionErrorMessage',
    commonLabels: 'commonLabels',
    options: 'option',
    personalInfo: 'personalInfo',
    vehicleData: 'vehicleData',
    policyData: 'policyData',
    quoteHistory: 'quoteHistory',
    uploadedFiles:'uploadedFiles'
};
