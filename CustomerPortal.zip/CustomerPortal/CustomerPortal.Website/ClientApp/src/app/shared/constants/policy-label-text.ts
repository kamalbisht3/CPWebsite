export const PolicyDetailLabelTextConstants = {   

    CPPolicyInfo: "CP/PolicyInfo",
    CPPolicyInfoCancelPolicy:"CP/PolicyInfo/CancelPolicy",
    CPPolicyInfoChangeModifyPolicy:"CP/PolicyInfo/ChangeModifyPolicy",
    CPPolicyinfoCoverage:"CP/Policyinfo/Coverage",
    CPPolicyInfoDeductable:"CP/PolicyInfo/Deductable",
    CPPolicyInfoExpiryDate:"CP/PolicyInfo/ExpiryDate",
    CPPolicyinfoLinktoDownload: "CP/Policyinfo/LinktoDownload",
    CPPolicyinfoLogo:"CP/Policyinfo/Logo",
    CPPolicyinfoPolicyno:"CP/Policyinfo/Policyno",
    CPPolicyInfoPremium:"CP/PolicyInfo/Premium",
    CPPolicyinfoPrice:"CP/Policyinfo/Price",
    CPPolicyInfoRenewPolicy:"CP/PolicyInfo/RenewPolicy",
    CPPolicyinfoStartdateofpolicy:"CP/Policyinfo/Startdateofpolicy",
    CPPolicyInfoUploadphotosDocs:"CP/PolicyInfo/UploadphotosDocs"
};
