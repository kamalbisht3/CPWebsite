export const PolicyCardLabelTextConstants = {   
    CPPolicycard: "CP/VICP/Policycard",
    CPPolicycardCommencementDate: "CP/Policycard/CommencementDate",
    CPPolicycardCoverage: "CP/Policycard/Coverage",
    CPPolicycardExpiryDate:"CP/Policycard/ExpiryDate",
    CPPolicycardFirstName: "CP/Policycard/FirstName",
    CPPolicycardinfoGraphic: "CP/Policycard/infoGraphic",
    CPPolicycardLastName: "CP/Policycard/LastName",
    CPPolicycardlogo: "CP/Policycard/logo",
    CPPolicycardPolicyNumber:"CP/Policycard/PolicyNumber",
    CPPolicycardVehicle:"CP/Policycard/Vehicle",
};
