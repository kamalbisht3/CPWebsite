export const QuoteHistoryLabelTextConstants = {   
    CPQH: "CP/QH",
    CPQHcoverage: "CP/QH/coverage",
    CPQHLandbackonCJ: "CP/QH/LandbackonCJ",
    CPQHLandbackonQuoteButton:"CP/QH/LandbackonQuoteButton",
    CPQHLatestMiniPriceQuote: "CP/QH/LatestMiniPriceQuote",
    CPQHlogo: "CP/QH/logo",
    CPQHprice: "CP/QH/price",
    CPQHVisitQuotes:"CP/QH/VisitQuotes",
    CPQHGoToCJ:"CP/QH/GoToCJ"
};
