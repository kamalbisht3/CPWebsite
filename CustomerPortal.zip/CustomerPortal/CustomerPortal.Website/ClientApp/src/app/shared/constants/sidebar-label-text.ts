export interface Sidebar {
    path: string;
}

export const SideBarLabelTextConstants: Sidebar[] = [
    { path: 'CP/SideBar/Home'},
    { path: 'CP/SideBar/Menu'},
    { path: 'CP/SideBar/PersonalDetails'},
    { path: 'CP/SideBar/Policy'},
    { path: 'CP/SideBar/QH'},
    { path: 'CP/SideBar/VI'},
];
