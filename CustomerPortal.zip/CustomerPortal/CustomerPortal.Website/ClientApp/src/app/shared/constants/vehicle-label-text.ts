export const VehicleDetailLabelTextConstants = {   
    CPVI: "CP/VI",
    CPVIBrand: "CP/VI/Brand",
    CPVIModel: "CP/VI/Model",
    CPVIPlateNo:"CP/VI/PlateNo",
    CPVISeqNumberCID: "CP/VI/SeqNumberCID",
    CPVITransmissiontype: "CP/VI/Transmissiontype",
    CPVIvehiclePurpose: "CP/VI/vehiclePurpose",
    CPVIYearofManufacture: "CP/VI/YearofManufacture",
    CPVIQuoteDate:"CP/VI/QuoteDate",
};
