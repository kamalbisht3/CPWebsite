export enum culture {
    ar = 1,
    en
}
