export enum VehicleIdEnum {
    Custom = 1,
    Serial,
}
