import { Observable, BehaviorSubject, timer  } from 'rxjs';

import { tap,retryWhen, delay,take, catchError } from 'rxjs/operators';
import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler,HttpEvent, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})

export class RequestInterceptorService implements HttpInterceptor {
    count=0;
    delayCount = 0;
    constructor() {
       
    }

    getDelayCount(){
      let localCount = this.count;
      return localCount;
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
     
        return next.handle(this.addToken(request, "token")).pipe(
            retryWhen(errors => errors
              .pipe(
                tap((errors) => {  
                  if(errors.status!=undefined && errors.status!=1 && errors.status !=0 && errors.status!=404 )
                  {
                    console.log(errors);
                    throw {errors};
                  }
                  console.log("retrying...");
                   this.count++;
                   if(this.count==1)
                   {
                     throw errors;
                   }
                }),
                delay(1000)
              )
            )
        )
    }

    addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
        return req.clone({
            headers: req.headers.set('Cache-Control', 'no-cache')
                .set('Pragma', 'no-cache')
                .set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT')
                .set('If-Modified-Since', '0') })
    }
}
