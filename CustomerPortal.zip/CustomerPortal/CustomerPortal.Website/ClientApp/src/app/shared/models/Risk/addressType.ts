export interface addressType {
    zipCode?: number;
    numberRoad?: string;
    city?: string;
    country?: string;
}
