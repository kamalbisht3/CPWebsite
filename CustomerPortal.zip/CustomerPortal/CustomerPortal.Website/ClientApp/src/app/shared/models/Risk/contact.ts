export interface contact {
    telephone?: string;
    email?: string;
}
