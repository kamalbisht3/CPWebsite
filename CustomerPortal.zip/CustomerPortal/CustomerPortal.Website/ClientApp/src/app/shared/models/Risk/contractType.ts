import {vehicle} from './vehicle';
import {policyHolderDetails} from './policyHolderDetails';
import {drivers} from './drivers';
import {policyInfo} from './policyInfo';
import {optDetails} from './optDetails';

export interface contractType {
    vehicle?: vehicle;
    policyHolderDetails?: policyHolderDetails;
    drivers?: drivers[];
    policyInfo?: policyInfo;
    optDetails?: optDetails;
    partner?: string;
}
