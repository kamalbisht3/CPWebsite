export interface coverDetails {
    excessAmount?: number;
    repair?: number;
    sumInsured?: number;
}
