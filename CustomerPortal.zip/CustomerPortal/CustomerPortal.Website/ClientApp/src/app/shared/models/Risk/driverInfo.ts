import {licenseInfo} from './licenseInfo';
import {violationInfo} from './violationInfo';
import {telematics} from './telematics';

export interface driverInfo {
    medicalConditions?: any[];
    licenseInfo?: licenseInfo;
    violationInfo?: violationInfo;
    drivingPercentage?: number;
    telematics?: telematics;
}
