import {vehicleUserInfo} from './vehicleUserInfo';
export interface drivers extends vehicleUserInfo {
    relationship?: number;
    isMainDriverPolicyHolder?: boolean;
    nationalId?: string;
    name?: string;
    dob?: string;
}
