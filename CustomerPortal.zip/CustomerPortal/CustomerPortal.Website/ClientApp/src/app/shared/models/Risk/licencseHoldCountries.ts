import {licencseHoldCountry} from './licencseHoldCountry';
export interface licencseHoldCountries {
    licencseHoldCountry?: licencseHoldCountry[];
}
