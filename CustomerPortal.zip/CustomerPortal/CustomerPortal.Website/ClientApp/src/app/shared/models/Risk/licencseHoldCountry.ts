export interface licencseHoldCountry {
    countryName?: string;
    licencseHoldForYear?: number;
}
