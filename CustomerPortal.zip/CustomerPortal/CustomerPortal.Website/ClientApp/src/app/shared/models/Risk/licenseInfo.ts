import {licencseHoldCountries} from './licencseHoldCountries';
export interface licenseInfo {
    licenseType?: any;
    saudiLicencseHoldForYear?: number;
    isLicencseHoldCountries?: boolean;
    licencseHoldCountries?: licencseHoldCountries;
    noClaimDiscountEligibleYear?: number;

}
