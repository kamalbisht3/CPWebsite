export interface officeAddress {
    zipCode?: number;
    numberRoad?: string;
    city?: string;
    country?: string;
}
