export interface optDetails {
    isTermsAndConditionsAccepted?: boolean;
    isTermsAndConditionsAcceptedSpecified?: boolean;
    consentELM_NajmConsultation?: boolean;
    consentELM_NajmConsultationSpecified?: boolean;
    isNewsletter?: boolean;
    dataStorePermission?: boolean;
    }
