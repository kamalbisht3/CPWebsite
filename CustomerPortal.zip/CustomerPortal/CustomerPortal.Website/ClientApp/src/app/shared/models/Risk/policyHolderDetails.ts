import {contact} from './contact';

import {vehicleUserInfo} from './vehicleUserInfo';
import { addressType } from './addressType';

export interface  policyHolderDetails extends vehicleUserInfo  {
    firstName?: string;
    lastName?: string;
    contact?: contact;
    nationalAddress?: addressType;
    isNationalEqualsResidential?: boolean;
    isNationalEqualsResidentialSpecified?: boolean;
    isPromoCode?: boolean;
    promoCodeType?: number;
    ksaCompany?: string;
    compPromoCode?: string;
}
