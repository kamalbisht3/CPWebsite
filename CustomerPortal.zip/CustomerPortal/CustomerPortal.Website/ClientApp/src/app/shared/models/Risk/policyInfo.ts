import {coverDetails} from './coverDetails';
import { culture } from '../../enums/culture.enum';

export interface  policyInfo {
    coverageType?: number;
    policyType?: number;
    insurancePurpose?: number;
    coverDetails?: coverDetails;
    mileagePerYear?: number;
    coverageArea?: number;
    coverageAreaSpecified?: boolean;
    policyStartingDate?: string;
    policyDateCulture?: culture
}
