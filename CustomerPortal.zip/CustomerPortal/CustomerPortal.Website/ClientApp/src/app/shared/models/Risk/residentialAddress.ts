export interface residentialAddress {
    zipCode?: number;
    numberRoad?: string;
    city?: string;
    country?: string;
}
