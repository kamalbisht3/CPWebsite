import {contractType} from './contractType';
import { culture } from '../../enums/culture.enum';

export interface riskType {
    activityID?: string;
    contractType?: contractType;
    selectedCulture?: number;
}
