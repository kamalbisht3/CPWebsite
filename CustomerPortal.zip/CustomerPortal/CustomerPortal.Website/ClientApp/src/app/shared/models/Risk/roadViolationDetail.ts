export interface RoadViolationDetail {
    roadViolation?: number;
    roadViolationCount?: number;
}
