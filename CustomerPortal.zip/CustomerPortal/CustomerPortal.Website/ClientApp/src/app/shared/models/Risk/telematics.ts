export interface telematics {
    breaking?: any;
    aceleration?: any;
    cornering?: any;
    speedLimit?: any;
    timeOfDay?: any;
    mileage?: any;
    seatBeltUse?: any;
}
