import { vehicleFeatureDetail } from './vehicleFeatureDetail';
import { VehicleIdEnum } from '../../enums/vehicleId.enum';
import { culture } from '../../enums/culture.enum';

export interface vehicle {
        isNewCar?: boolean;
        isOwnerShipTransfer?: boolean;
        vehicleIdType?: VehicleIdEnum;
        sequenceNumber?: string;
        customId?: string;
        registartionDate?: string;
        RegistartionDateCulture?: culture;
        usage?: number;
        makeName?: string;
        manufacturingYear?: number;
        manufacturingYearSpecified?: boolean;
        modelName?: string;
        nightParking?: number;
        isFireExtinguisher?: boolean;
        currentMileage?: number;
        vehicleFeatureDetail?: vehicleFeatureDetail;
    }
