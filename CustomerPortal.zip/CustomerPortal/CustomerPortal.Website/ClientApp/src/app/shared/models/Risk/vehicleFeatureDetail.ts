export interface vehicleFeatureDetail {
    engineSize?: number;
    antiTheftAlaram?: boolean;
    antiLockBraking?: boolean;
    autoBrakingSys?: boolean;
    cruiseControl?: number;
    sensors?: number;
    cameras?: number;
    isModification?: boolean;
    modifications?: number[];
    numberOfSeats?: number;
    transmission?: number;
    vehicleAxleWeight?: number;
}
