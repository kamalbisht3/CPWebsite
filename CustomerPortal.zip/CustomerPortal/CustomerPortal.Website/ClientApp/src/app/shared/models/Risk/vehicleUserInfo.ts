import {driverInfo} from './driverInfo';
import { culture } from '../../enums/culture.enum';
import { addressType } from './addressType';
export interface vehicleUserInfo {
    FullName?: string;
    FormControlId?: number;
    maritalStatus?: number;
    childUnder16?: number;
    vehicleDriveCity?: string;
    gender?: number;
    education?: number;
    occupation?: number;
    driverInfo?: driverInfo;
    officeAddress?: addressType;
    residentialAddress?: addressType;
    birthDate?: string;
    birthDateCulture?: culture;
    userIdType?: number; //buss/indi (national/iqma)
    userId?: string;
}
