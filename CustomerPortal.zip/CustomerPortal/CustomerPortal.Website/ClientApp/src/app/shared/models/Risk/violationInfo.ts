import { RoadViolationDetail } from './roadViolationDetail';

export interface violationInfo {
    faultAccident?: any;
    faultClaims?: any;
    roadViolations?: RoadViolationDetail[];
}
