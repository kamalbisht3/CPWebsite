﻿export interface CommonLabelText {
    labelPath: string;
    labelValue_ar: string;
    labelValue_en: string;
}