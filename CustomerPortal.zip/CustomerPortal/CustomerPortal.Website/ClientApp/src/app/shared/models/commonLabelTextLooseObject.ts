﻿import { CommonLabelText } from './common-label-text';

export interface CommonLabelTextLooseObject {
    [key: string]: CommonLabelText;
}