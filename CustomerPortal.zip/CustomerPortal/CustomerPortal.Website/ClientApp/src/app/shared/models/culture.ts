import { ChangeDetectorRef, ElementRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { InternalizationService } from '../services/internalization.service';
import { CommonLabelTextConstants } from '../constants/common-label-text';
import { CommonLabelHandlerService } from '../services/commonlabel-handler.service';
//import { culture } from '../../../shared/enums/culture.enum';

export abstract class Culture {
    public currentCulture: string = "en";
    public langSubscribe: Subscription;

    
    optionData: any;

    constructor(public internalizationService: InternalizationService, public changeDetection: ChangeDetectorRef,public commonLabelHandlerService: CommonLabelHandlerService) {
        this.currentCulture = internalizationService.getCurrentLocale().startsWith('ar') ? 'ar' : 'en';
    }

    public getLabel(labelId: string) {
        return this.commonLabelHandlerService.getLabelData(labelId, this.currentCulture);
    }

    public cultureInitiallizer() {
        this.langSubscribe = this.internalizationService.currentLanguage.subscribe((lang) => {
            this.currentCulture = lang;
            this.changeDetection.markForCheck();
        });
    }

    ngOnDestroy() {
        this.langSubscribe.unsubscribe();
    }
}
