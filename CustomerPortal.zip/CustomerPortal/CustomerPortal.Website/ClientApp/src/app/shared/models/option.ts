import { questionOptions } from './questionOptions';
export interface option {
    questionOptions: questionOptions[];
}
