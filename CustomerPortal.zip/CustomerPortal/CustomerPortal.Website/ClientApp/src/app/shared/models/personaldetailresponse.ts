export interface personaldetailResponse {
    status: number;
    customerActivityID: string;
    risk: string;
}
