export interface policydetailResponse {
    risk: string;
    policyInfoID: number;
    customerActivity_ID: string;
    brand_ID: number;
    proposalNumber: string;
    policyNumber: string;
    policyInfo: string;
}
