export interface questionOptions {
    questionID: number;
    lookupID: number;
    product_ID: number;
    lookupValue_ar: string;
    lookupValue_en: string;
    rank: number;
}
