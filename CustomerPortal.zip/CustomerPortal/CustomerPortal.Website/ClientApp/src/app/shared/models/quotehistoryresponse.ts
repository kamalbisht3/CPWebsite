export interface QuoteHistoryResponse {
    customerActivity_ID: string;
    brand_ID: number;
    coverType: number;
    resultObject: string;
}
