export interface serverResponse<T> {
    response: T;
    status: boolean;
    statusCode: number;
    message: string;
    errorMessage: string[];

}
