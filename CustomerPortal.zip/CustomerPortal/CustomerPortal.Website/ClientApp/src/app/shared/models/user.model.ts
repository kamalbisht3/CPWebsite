export interface User {
  email?: string;
  username?: string;
  image?: string;
  userAccountStatus: number;
  resultSet: string;
}
