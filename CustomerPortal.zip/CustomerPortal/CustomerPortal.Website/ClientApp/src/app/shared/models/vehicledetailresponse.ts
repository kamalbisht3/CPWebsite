export interface VehicleDetailResponse {
    vehicleMasterID: number;
    modelname: string;
    makename: string;
    platenumber: string;
}
