import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { CommonLabelTextLooseObject } from '../models/commonLabelTextLooseObject';
import { CommonLabelService } from './commonlabel.service';


@Injectable()
export class CommonLabelHandlerService { 
    allCommonLabel: any;
    commonLabelTextLooseObject: CommonLabelTextLooseObject = {};

    private isDataAvailableSubject = new ReplaySubject<boolean>(1);
    public isDataAvailable = this.isDataAvailableSubject.asObservable();

    constructor(private commonLabel: CommonLabelService, private memoryStorageService: MemoryStorageService) {

        this.allCommonLabel = this.GetcommonLabel();
        if (this.allCommonLabel == null) {
            this.commonLabel.getCommonLabelsText().subscribe(() => {
                this.allCommonLabel = this.GetcommonLabel();
                //console.log(this.allCommonLabel);
                this.GetCommanTextLabel();
                this.isDataAvailableSubject.next(true);
            });
        }
    }

    private GetcommonLabel() {
        return this.memoryStorageService.get(memoryStorageKey.commonLabels);
    }

    GetCommanTextLabel(): CommonLabelTextLooseObject {
        if (Object.keys(this.commonLabelTextLooseObject).length === 0 && this.commonLabelTextLooseObject.constructor === Object)
            this.allCommonLabel.forEach(val => {
                this.commonLabelTextLooseObject[val.labelPath] = val;
            });
        return this.commonLabelTextLooseObject;
    }

    getLabelData(path : string, culture: string) {
        if (this.commonLabelTextLooseObject[path]) {
            var data = this.commonLabelTextLooseObject[path]['labelValue_' + culture];
            return (data) ? data : "";
        }
    }
}

