import { Injectable } from '@angular/core';
import { Observable ,  BehaviorSubject ,  ReplaySubject } from 'rxjs';
import { map ,  distinctUntilChanged } from 'rxjs/operators';
import { UserService } from '../../shared/services/user.service';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { User } from '../../shared/models/user.model';
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { CommonLabelText } from '../models/common-label-text';


@Injectable()
export class CommonLabelService {
   constructor(private http: HttpWrapperService, private memoryStorageService: MemoryStorageService,
   private apiEndpointsService: ApiEndpointsService,
  ) {}

    getCommonLabelsText(): Observable<serverResponse<CommonLabelText[]>> {
        return this.http.get(this.apiEndpointsService.resolve(this.apiEndpointsService.endPoints.commonlabels))
            .pipe(map((result: any) => {

                if (result.status) {
                    this.memoryStorageService.set(memoryStorageKey.commonLabels, result.response)
                }
                return result;
            },
                (error) => { console.error(error.message); }));
    }



}

