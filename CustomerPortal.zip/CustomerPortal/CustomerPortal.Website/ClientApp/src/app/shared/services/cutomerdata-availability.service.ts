import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class CustomerDataAvailabilty {
    private isCustomerDataAvailableSubject = new Subject<boolean>();
    public isCustomerDataAvailable = this.isCustomerDataAvailableSubject.asObservable();

    gotData() {
        this.isCustomerDataAvailableSubject.next(true);
    }
}
