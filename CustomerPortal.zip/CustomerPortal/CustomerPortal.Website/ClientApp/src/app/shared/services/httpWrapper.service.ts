import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpRequest, HttpErrorResponse, } from "@angular/common/http";
import { catchError, retry } from 'rxjs/operators';

@Injectable()
export class HttpWrapperService {

    constructor(private http: HttpClient) { }

    get(url: string, data?: {}) {
        return this.http.get(url, data)
            .pipe(
                catchError(this.handleError)
            );
    }

    getMapped<T>(url: string, data?: any) {
        return this.http.get<T>(url, data)
            .pipe(
                catchError(this.handleError)
            );
    }

    postMapped<T>(url: string, data?: any) {
        return this.http.post<T>(url, data)
            .pipe(
                catchError(this.handleError)
            );
    }

    post(url: string, data?: any) {
        return this.http.post(url, data)
            .pipe(
                catchError(this.handleError)
            );
    }

    postWithHeader(url: string, data: any, options?: any) {
        return this.http.post(url, data, options)
            .pipe(
                catchError(this.handleError)
            );
    }

    private handleError(error: HttpErrorResponse) {
        console.error(error);
        return throwError(error);
    };

    put(url: string, data?: any) {
        return this.http.put(url, data)
            .pipe(
                catchError(this.handleError)
            );
    }

    delete(url: string, options?: any) {
        return this.http.delete(url, options)
            .pipe(
                catchError(this.handleError)
            );
    }
}
