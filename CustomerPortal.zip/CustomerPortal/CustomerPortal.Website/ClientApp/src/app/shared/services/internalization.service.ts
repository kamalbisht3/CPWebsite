import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { LocalStorageService } from './storage/local-storage.service';
import { culture } from '../enums/culture.enum';

@Injectable()
export class InternalizationService {

    private currentLanguageSubject = new Subject<string>();
    public currentLanguage = this.currentLanguageSubject.asObservable();
    public currentCulture: culture = culture.en;
    public defaultLocaleId = 'en-us';
    public implementedLocales = ['ar', this.defaultLocaleId];

    constructor(private localStorageService: LocalStorageService) {

        var currentCulture = this.getCurrentLocale();
        if (currentCulture == "en-us")
            this.currentCulture = culture.en;
        else
            this.currentCulture = culture.ar;

        this.currentLanguageSubject.next(this.currentCulture == culture.ar ? 'ar' : 'en');
    }

    public getCurrentLocale(): string {

        // Retrieve localeId from the url if any; otherwise, default to 'en-US'.
        // The first time the app loads, check the browser language.
        const storedLocaleId = this.localStorageService.get('__localeId');
        if (storedLocaleId == null) {
            let partialLocaleMatch = null;
            // tslint:disable-next-line:forin
            for (const id in this.implementedLocales) {
                const implemetedLocaleId = this.implementedLocales[id];
                if (navigator.language === implemetedLocaleId) {
                    // Exact match, return.
                    return implemetedLocaleId;
                } else if (navigator.language.startsWith(implemetedLocaleId)) {
                    // For example, browser has `es-CL` and the implemented locale is `es`.
                    partialLocaleMatch = implemetedLocaleId;
                } else if (implemetedLocaleId.startsWith(navigator.language)) {
                    // For example, browser has `es` and the implemented locale is `es-CL`.
                    partialLocaleMatch = implemetedLocaleId;
                }
            }
            if (partialLocaleMatch != null) { return partialLocaleMatch; }
        }
        return storedLocaleId || this.defaultLocaleId;
    }

    public setCurrentLocale(localeId: string) {
        this.localStorageService.set('__localeId', localeId);
    }


    public changeLanguage(cult: culture) {

        if (cult == culture.en) {
            this.currentLanguageSubject.next('en');


            this.setCurrentLocale('en-us');
        }
        else if (cult == culture.ar) {
            this.currentLanguageSubject.next('ar');

            this.setCurrentLocale('ar');
        }

        this.currentCulture = cult;
    }
}
