import { Injectable, ChangeDetectorRef } from '@angular/core';
import { Observable ,  BehaviorSubject ,  ReplaySubject, Subscription } from 'rxjs';
import { map ,  distinctUntilChanged } from 'rxjs/operators';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../constants/memoryStorageKey';
import { option } from '../models/Option';
import { OptionsService } from './options.service';
import { InternalizationService } from './internalization.service';



@Injectable()
export class OptionsHandlerService {
    public currentCulture: string = "en";
    public langSubscribe: Subscription;
    allOptionsGenerator: any;
    filterOptionValue: any;
    constructor(public internalizationService: InternalizationService,private optionsService: OptionsService,private memoryStorageService: MemoryStorageService
    )
    {
       this.allOptionsGenerator = this.GetOptionsGenerator();
       if (this.allOptionsGenerator  == null) {
           this.optionsService.getOptions().subscribe(() => {

               this.allOptionsGenerator = this.GetOptionsGenerator();
               //console.log(this.allOptionsGenerator);
           });

       }
       else {
           this.allOptionsGenerator = {};
       }
   }

    private GetOptionsGenerator() {
        return this.memoryStorageService.get(memoryStorageKey.options);
    }

    GetOptionValue(QuestionId: number, lookupId: number, culture: string) {
        if (this.allOptionsGenerator) {
            this.filterOptionValue = this.allOptionsGenerator.filter((t) => t.questionID === QuestionId && t.lookupID === lookupId);
            if (this.filterOptionValue.length > 0) {
                return this.filterOptionValue[0]['lookupValue_' + culture]
            }
        }

        return "*******";
    }
}

