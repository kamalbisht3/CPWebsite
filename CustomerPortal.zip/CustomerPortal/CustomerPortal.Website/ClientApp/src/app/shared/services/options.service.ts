import { Injectable } from '@angular/core';
import { Observable ,  BehaviorSubject ,  ReplaySubject } from 'rxjs';
import { map ,  distinctUntilChanged } from 'rxjs/operators';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../constants/memoryStorageKey';
import { option } from '../models/Option';



@Injectable()
export class OptionsService {
   constructor(private http: HttpWrapperService, private memoryStorageService: MemoryStorageService,
   private apiEndpointsService: ApiEndpointsService,
  ) {}

    getOptions(): Observable<serverResponse<option>> {
        return this.http.get(this.apiEndpointsService.resolve(this.apiEndpointsService.endPoints.option))
            .pipe(map((result: any) => {
                if (result.status) {
                    this.memoryStorageService.set(memoryStorageKey.options, result.response)
                }
                return result;
            },
                (error) => { console.error(error.message); }));
    }



}

