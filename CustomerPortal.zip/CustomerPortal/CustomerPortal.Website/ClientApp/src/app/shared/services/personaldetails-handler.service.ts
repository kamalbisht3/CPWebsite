import { Injectable } from '@angular/core';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../constants/memoryStorageKey';
import { PersonalDetailService } from './personaldetails.service';
import { CustomerDataAvailabilty } from './cutomerdata-availability.service';

@Injectable()
export class PersonalDetailsHandlerService {
    personalDetails: any;

    constructor(private personalDetailService: PersonalDetailService, private memoryStorageService: MemoryStorageService, private customerDataAvailabilty: CustomerDataAvailabilty) {
        this.personalDetails = this.GetOptionsGenerator();
        if (this.personalDetails == null) {
            this.personalDetailService.getPersonalDetail().subscribe(() => {
                this.personalDetails = this.GetOptionsGenerator();
                this.customerDataAvailabilty.gotData();
            });
        }
        else {
            this.personalDetails = {};
        }
    }

    private GetOptionsGenerator() {
        return this.memoryStorageService.get(memoryStorageKey.personalInfo);
    }


    GetPersonalInfo() {
        return this.personalDetails;
    }
}

