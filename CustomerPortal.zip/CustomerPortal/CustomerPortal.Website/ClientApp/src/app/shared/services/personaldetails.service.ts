import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
import { map, distinctUntilChanged } from 'rxjs/operators';
import { personaldetailResponse } from '../models/personaldetailResponse';
import { memoryStorageKey } from '../constants/memoryStorageKey';
import { MemoryStorageService } from './storage/memory-storage.service';
import { HttpWrapperService } from './httpWrapper.service';
import { ApiEndpointsService } from './endpoints.service';
import { serverResponse } from '../models/server-response';

@Injectable()
export class PersonalDetailService {

    constructor(private http: HttpWrapperService, private apiEndpointsService: ApiEndpointsService, private memoryStorageService: MemoryStorageService) { }

    getPersonalDetail(): Observable<serverResponse<personaldetailResponse>> {
        return this.http.get(this.apiEndpointsService.resolve(this.apiEndpointsService.endPoints.personaldetail))
            .pipe(map((result: any) => {

              if (result.response) {
                const _result = JSON.parse(result.response.risk);
                this.memoryStorageService.set(memoryStorageKey.personalInfo, _result)
                return _result;
              }
            },
                (error) => { console.error(error.message); }));
    }
}

