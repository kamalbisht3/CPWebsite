import { Injectable } from '@angular/core';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { memoryStorageKey } from '../constants/memoryStorageKey';
import { CustomerDataAvailabilty } from './cutomerdata-availability.service';
import { PolicyDataService } from './policy.service';

@Injectable()
export class PolicyDataHandlerService {
    policyData: any;

    constructor(private policyDataService: PolicyDataService, private memoryStorageService: MemoryStorageService, private customerDataAvailabilty: CustomerDataAvailabilty) {
        this.policyData = this.GetOptionsGenerator();
        if (this.policyData == null) {
            this.policyDataService.getPolicyDetail().subscribe(() => {
                this.policyData = this.GetOptionsGenerator();
                this.customerDataAvailabilty.gotData();
            });
        }
        else {
            this.policyData = {};
        }
    }

    private GetOptionsGenerator() {
        return this.memoryStorageService.get(memoryStorageKey.policyData);
    }

    //segregateData() {
    //    this.policyData.forEach(data => {
    //        var risk = JSON.parse(data.risk).ContractType;
    //        this.vehicleInfo.push(risk.Vehicle);
    //        this.policyHolderInfo.push({ firstName: risk.PolicyHolderDetails.FirstName, lastName: risk.PolicyHolderDetails.LastName });
    //        if (risk.Drivers.length > 1) {
    //            this.driverInfo.push({ firstName: risk.drivers.FirstName, lastName: risk.drivers.LastName });
    //        }
    //    })
    //}

    GetPolicyInfo() {
        return this.policyData;
    }
}

