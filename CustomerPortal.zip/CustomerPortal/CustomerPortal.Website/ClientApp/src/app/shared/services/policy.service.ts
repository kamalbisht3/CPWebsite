import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { memoryStorageKey } from '../constants/memoryStorageKey';
import { MemoryStorageService } from './storage/memory-storage.service';
import { policydetailResponse } from '../models/policydetailresponse';
import { HttpWrapperService } from './httpWrapper.service';
import { ApiEndpointsService } from './endpoints.service';
import { serverResponse } from '../models/server-response';

@Injectable()
export class PolicyDataService {

    constructor(private http: HttpWrapperService, private apiEndpointsService: ApiEndpointsService, private memoryStorageService: MemoryStorageService) { }

    getPolicyDetail(): Observable<serverResponse<policydetailResponse[]>> {
        return this.http.get(this.apiEndpointsService.resolve(this.apiEndpointsService.endPoints.policyData))
            .pipe(map((result: any) => {
                if (result.status)
                    this.memoryStorageService.set(memoryStorageKey.policyData, result.response)
                return result;
            },
                (error) => { console.error(error.message); }));
    }


}

