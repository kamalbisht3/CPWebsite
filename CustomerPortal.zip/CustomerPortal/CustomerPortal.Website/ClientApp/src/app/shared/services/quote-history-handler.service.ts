import { Injectable } from '@angular/core';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { QuoteDataService } from './quote-history.service';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { CustomerDataAvailabilty } from './cutomerdata-availability.service';

@Injectable()
export class QuoteHistoryHandlerService {
    quoteHistory: any;
    isQuoteFound: boolean = false;

    constructor(private quoteDataService: QuoteDataService, private memoryStorageService: MemoryStorageService, private customerDataAvailabilty: CustomerDataAvailabilty) {
        this.quoteHistory = this.GetOptionsGenerator();
        if (this.quoteHistory == null) {
            this.quoteDataService.getQuoteHistory().subscribe(() => {
                this.quoteHistory = this.GetOptionsGenerator();
                this.customerDataAvailabilty.gotData();
                this.isQuoteFound = true;
            });
        }
        else {
            this.quoteHistory = {};
        }
    }

    private GetOptionsGenerator() {
        return this.memoryStorageService.get(memoryStorageKey.quoteHistory);
    }


    GetVehicleInfo() {
        return this.quoteHistory;
    }
}

