import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { QuoteHistoryResponse } from '../models/quotehistoryresponse';

@Injectable()
export class QuoteDataService {

    constructor(private http: HttpWrapperService, private apiEndpointsService: ApiEndpointsService, private memoryStorageService: MemoryStorageService) { }

    getQuoteHistory(): Observable<serverResponse<QuoteHistoryResponse[]>> {
        return this.http.get(this.apiEndpointsService.resolve(this.apiEndpointsService.endPoints.quoteHistory))
            .pipe(map((result: any) => {
                if (result.status)
                    this.memoryStorageService.set(memoryStorageKey.quoteHistory, result.response)
                return result;
            },
                (error) => { console.error(error.message); }));
    }
}

