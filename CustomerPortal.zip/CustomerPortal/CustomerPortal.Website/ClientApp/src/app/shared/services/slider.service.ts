import { Injectable } from '@angular/core';

@Injectable()
export class SliderService {
    current = 0;
    prev = -1;

    onPrev() {
        this.prev = this.current--;
    }

    onNext() {
        this.prev = this.current++;
    }

    isLeftTransition(idx: number): boolean {
        return this.current === idx ? this.prev > this.current : this.prev < this.current;
    }
}
