
export class InMemoryStorage implements Storage{
    private readonly storage: Map<string, string> = new Map<string, string>();

    public length: number = 0;

    public getItem(key: string): string{
        if(this.length <= 0)
            return undefined;
        return this.storage.get(key);
    }    
      
    key(index: number): string | null
    {
        if(index > -1 && index < this.length)
            return this.storage.keys[index];

        return undefined;
    }

    public setItem(key: string, value: string) : void{
      var data = this.storage.set(key, value);
      this.length = data.size;

      //console.log(this.storage);
    }
  
    public clear() : void{
      this.storage.clear();
       this.length = 0
    }
  
    public removeItem(key: string) : void{
      if(this.storage.delete(key))
        this.length--;
    }
}
