import { InMemoryStorage } from '../core/memory-storage';


export function GetAvailableStorage(storage: Storage): Storage {
    // Check if storage is available.
    if (storage) {
    // Check if the storage can actually be accessed.
    try {
        const now = Date.now();
        const testItemKey = `storage-test-entry-${now}`;
        const testItemValue = `storage-test-value-${now}`;
        storage.setItem(testItemKey, testItemValue);
        const retrievedItemValue = storage.getItem(testItemKey);
        storage.removeItem(testItemKey);

        if (retrievedItemValue === testItemValue) {
            return storage;
        }
    } catch (error) {}
}
    return new InMemoryStorage();
}

