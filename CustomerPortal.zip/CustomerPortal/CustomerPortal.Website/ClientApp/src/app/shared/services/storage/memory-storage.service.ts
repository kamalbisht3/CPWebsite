import { Injectable } from '@angular/core';
import { StorageService } from './storage.service';
import { InMemoryStorage } from './core/memory-storage';

@Injectable({
  providedIn: 'root'
})
export class MemoryStorageService extends StorageService {
  constructor() {
    super(new InMemoryStorage());
  }
}


