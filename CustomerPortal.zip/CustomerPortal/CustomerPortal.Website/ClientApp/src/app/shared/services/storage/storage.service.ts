export class StorageService {

    constructor(private storage: Storage) { }

    public get(key: string) {

        const value = this.parse(this.storage.getItem(key) || 'null') || null;
        if (value === null) { return null; }

        if (
            typeof value === 'object' &&
            typeof value._expired !== 'undefined' &&
            value._expired !== 0 &&
            +new Date() > value._expired
        ) {
            this.remove(key);
            return null;
        }

        return value._value || null;
    }

    public set(key: string, value: any, expiredAt: number = 0, expiredUnit: string = 'h'): void {
        this.storage.setItem(
            key,
            this.stringify({
                _expired: this.getExpired(expiredAt, expiredUnit),
                _value: value,
            }),
        );
    }

    public remove(key: string | RegExp): void {
        if (typeof key === 'string') {
            this.storage.removeItem(key);
            return;
        }
        let index = 0;
        let next = this.key(index);
        const ls: string[] = [];
        while (next) {
            if (key.test(next)) { ls.push(next); }
            next = this.key(++index);
        }
        ls.forEach(v => this.storage.removeItem(v));

    }

    public clear(): void {
        this.storage.clear();
    }

    key(index: number): string {
        return this.storage.key(index);
    }

    private getExpired(val: number, unit: string): number {
        if (val <= 0) { return 0; }
        const now = +new Date();
        switch (unit) {
            case 's':
                return now + 1000 * val;
            case 'm':
                return now + 1000 * 60 * val;
            case 'h':
                return now + 1000 * 60 * 60 * val;
            case 'd':
                return now + 1000 * 60 * 60 * 24 * val;
            case 'w':
                return now + 1000 * 60 * 60 * 24 * 7 * val;
            case 'y':
                return now + 1000 * 60 * 60 * 24 * 365 * val;
            case 't':
                return now + val;
        }
        return 0;
    }

    private stringify(value: any) {
        return JSON.stringify(value);
    }

    private parse(value: string) {
        try {
            return JSON.parse(value);
        } catch (Ex) {
            return value;
        }
    }

}
