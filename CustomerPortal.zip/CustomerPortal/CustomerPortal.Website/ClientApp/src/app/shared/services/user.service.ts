import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
import { map, distinctUntilChanged } from 'rxjs/operators';
import { User } from '../models/user.model';
import { HttpWrapperService } from './httpWrapper.service';
import { ApiEndpointsService } from './endpoints.service';


@Injectable()
export class UserService {
    private currentUserSubject = new BehaviorSubject<User>({} as User);
    public currentUser = this.currentUserSubject.asObservable().pipe(distinctUntilChanged());

    private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
    public isAuthenticated = this.isAuthenticatedSubject.asObservable();

    constructor(private http: HttpWrapperService, private apiEndpointsService: ApiEndpointsService) {
        //this.setAuthentication(false);
        this.getAndSetAuthenticationStatus();
    }

    getAndSetAuthenticationStatus() {
        this.isUserAuthentcated().subscribe(val => { this.setAuthentication(val); });
    }

    private isUserAuthentcated() {
        return this.http.getMapped<boolean>(this.apiEndpointsService.endPoints.isUserAuthenticated);
    }

    logoutUser() {
        return this.http.get(this.apiEndpointsService.endPoints.userlogout);
    }


    purgeAuth() {
        // Set current user to an empty object
        this.currentUserSubject.next({} as User);
        // Set auth status to false
        this.isAuthenticatedSubject.next(false);
    }


    getCurrentUser(): User {
        return this.currentUserSubject.value;
    }

    setCurrentUser(user: User) {
        this.currentUserSubject.next(user);
    }

    setAuthentication(status) {
        this.isAuthenticatedSubject.next(status);
    }
}
