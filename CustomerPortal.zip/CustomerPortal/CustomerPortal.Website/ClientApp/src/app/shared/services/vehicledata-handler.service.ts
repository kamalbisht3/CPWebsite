import { Injectable } from '@angular/core';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';
import { VehicleDataService } from './vehicledata.service';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { CustomerDataAvailabilty } from './cutomerdata-availability.service';

@Injectable()
export class VehicleDataHandlerService {
    vehicleData: any;

    constructor(private vehicleDataService: VehicleDataService, private memoryStorageService: MemoryStorageService, private customerDataAvailabilty: CustomerDataAvailabilty) {
        this.vehicleData = this.GetOptionsGenerator();
        if (this.vehicleData == null) {
            this.vehicleDataService.getVehiclelDetail().subscribe(() => {
                this.vehicleData = this.GetOptionsGenerator();
                this.customerDataAvailabilty.gotData();
            });
        }
        else {
            this.vehicleData = {};
            this.customerDataAvailabilty.gotData();
        }
    }

    private GetOptionsGenerator() {
        return this.memoryStorageService.get(memoryStorageKey.vehicleData);
    }


    GetVehicleInfo() {
        return this.vehicleData;
    }
}

