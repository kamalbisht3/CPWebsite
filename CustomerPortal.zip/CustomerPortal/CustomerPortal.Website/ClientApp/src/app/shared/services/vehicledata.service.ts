import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { VehicleDetailResponse } from '../models/vehicledetailresponse';
import { HttpWrapperService } from '../../shared/services/httpWrapper.service';
import { serverResponse } from '../../shared/models/server-response';
import { memoryStorageKey } from '../../shared/constants/memoryStorageKey';
import { ApiEndpointsService } from '../../shared/services/endpoints.service';
import { MemoryStorageService } from '../../shared/services/storage/memory-storage.service';

@Injectable()
export class VehicleDataService {

    constructor(private http: HttpWrapperService, private apiEndpointsService: ApiEndpointsService, private memoryStorageService: MemoryStorageService) { }

    getVehiclelDetail(): Observable<serverResponse<VehicleDetailResponse[]>> {
        return this.http.get(this.apiEndpointsService.resolve(this.apiEndpointsService.endPoints.vehicleData))
            .pipe(map((result: any) => {
                if (result.status)
                    this.memoryStorageService.set(memoryStorageKey.vehicleData, result.response)
                return result;
            },
                (error) => { console.error(error.message); }));
    }
}

