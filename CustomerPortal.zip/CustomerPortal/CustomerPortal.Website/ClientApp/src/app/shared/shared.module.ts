import { NgModule, ModuleWithProviders } from '@angular/core';
import { SidebarDirective } from './directives/sidebar.directive';
import { HttpWrapperService } from './services/httpWrapper.service';
import { InternalizationService } from './services/internalization.service';
import { UserService } from './services/user.service';
import { CommonLabelService } from './services/commonlabel.service';
import { CommonLabelHandlerService } from './services/commonlabel-handler.service';
import { ShowAuthedDirective } from './directives/show-authed.directive';
import { commonLabelsEndPoints } from './urlEndPoints/commonlabels-endpoints';
import { END_POINTS, ApiEndpointsService } from './services/endpoints.service';
import { cutureControlComponent } from './components/culture/culture.component';
import { CommonModule } from '@angular/common';
import { UserAuthEndPoints } from './urlEndPoints/auth-endpoints';
import { SliderComponent } from './components/slider/slider.component';
import { SliderPanelComponent } from './components/slider-panel/slider-panel.component';
import { SliderService } from './services/slider.service';
import { OptionEndPoints } from './urlEndPoints/option-endpoints';
import { OptionsService } from './services/options.service';
import { OptionsHandlerService } from './services/options-handler.service';
import { PersonalDetailService } from './services/personaldetails.service';
import { PersonalDetailsHandlerService } from './services/personaldetails-handler.service';
import { personaldetailEndPoints } from './urlEndPoints/personaldetails-endpoints';
import { VehicleDataEndPoints } from './urlEndPoints/vehicledata-endpoints';
import { UserIdleConfig } from './models/user-idle';
import { TimerComponent } from './components/timer/timer.component';
import { PolicyDataEndPoints } from './urlEndPoints/policy-endpoints';
import { CustomerDataAvailabilty } from './services/cutomerdata-availability.service';
import { PolicyDataService } from './services/policy.service';
import { PolicyDataHandlerService } from './services/policy-handler.service';
import { VehicleDataService } from './services/vehicledata.service';
import { VehicleDataHandlerService } from './services/vehicledata-handler.service';
import { QuoteDataService } from './services/quote-history.service';
import { QuoteHistoryHandlerService } from './services/quote-history-handler.service';
import { quoteHistoryEndPoints } from './urlEndPoints/quote-history-endpoints';

const COMMON_LABELS_URL = { provide: END_POINTS, multi: true, useValue: commonLabelsEndPoints };
const AUTH_URL = { provide: END_POINTS, multi: true, useValue: UserAuthEndPoints };
const OPTION_URL = { provide: END_POINTS, multi: true, useValue: OptionEndPoints };
const PERSONALDETAIL_URL = { provide: END_POINTS, multi: true, useValue: personaldetailEndPoints };
const VEHICLEDATA_URL = { provide: END_POINTS, multi: true, useValue: VehicleDataEndPoints };
const POLICYDATA_URL = { provide: END_POINTS, multi: true, useValue: PolicyDataEndPoints };
const QUOTEHISTORY_URL = { provide: END_POINTS, multi: true, useValue: quoteHistoryEndPoints }

@NgModule({
    declarations: [
        SidebarDirective, ShowAuthedDirective,
        cutureControlComponent,
        SliderComponent,
        TimerComponent,
        SliderPanelComponent
    ],
    imports: [
        CommonModule,
    ],
    
    exports: [SidebarDirective, ShowAuthedDirective, cutureControlComponent, SliderPanelComponent, SliderComponent, TimerComponent]
})
export class SharedModule {
  static forRoot(config: UserIdleConfig): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                ApiEndpointsService, COMMON_LABELS_URL, AUTH_URL, OPTION_URL, PERSONALDETAIL_URL,
                HttpWrapperService, VEHICLEDATA_URL, POLICYDATA_URL, QUOTEHISTORY_URL,
                InternalizationService,
                UserService, CommonLabelService, CommonLabelHandlerService, OptionsService, OptionsHandlerService,
                SliderService, PersonalDetailService, PersonalDetailsHandlerService, VehicleDataService, VehicleDataHandlerService,
                CustomerDataAvailabilty, PolicyDataService, PolicyDataHandlerService, QuoteDataService, QuoteHistoryHandlerService,
                { provide: UserIdleConfig, useValue: config }
            ],
        }
    }
}
