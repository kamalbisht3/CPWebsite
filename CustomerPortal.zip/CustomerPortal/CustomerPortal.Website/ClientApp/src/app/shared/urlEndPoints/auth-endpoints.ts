export const UserAuthEndPoints = {
    isUserAuthenticated: 'api/auth/isuserauthenticated',
    userlogout: 'api/auth/userlogout'
};
