export const commonLabelsEndPoints = {
    commonlabels: '/api/Label/allcommon',
};
