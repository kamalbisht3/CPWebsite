export const OptionEndPoints = {
    option: 'api/option/alloptions'
};
