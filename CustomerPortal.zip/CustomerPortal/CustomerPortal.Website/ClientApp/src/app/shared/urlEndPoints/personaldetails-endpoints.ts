export const personaldetailEndPoints = {
    personaldetail: 'api/personal/personaldetail',
};
