export const PolicyDataEndPoints = {
    policyData: 'api/policy/getinfo',
};
