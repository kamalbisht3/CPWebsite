interface EndPoints {
    isUserAuthenticated: string;
    userlogout: string;
}
