interface EndPoints {
  commonlabels: string
}
