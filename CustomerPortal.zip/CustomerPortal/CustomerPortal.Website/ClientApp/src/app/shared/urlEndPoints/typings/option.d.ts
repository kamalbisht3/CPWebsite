interface EndPoints {
    option: string;
}
