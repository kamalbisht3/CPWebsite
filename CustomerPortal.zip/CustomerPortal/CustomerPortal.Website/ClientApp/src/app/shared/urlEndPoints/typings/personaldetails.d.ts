interface EndPoints {
    personaldetail: string;
}
