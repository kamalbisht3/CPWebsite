interface EndPoints {
    policyData: string;
}
