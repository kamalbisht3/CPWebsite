interface EndPoints {
  quoteHistory: string
}
