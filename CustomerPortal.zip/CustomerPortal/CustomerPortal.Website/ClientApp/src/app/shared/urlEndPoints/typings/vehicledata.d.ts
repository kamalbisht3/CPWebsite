interface EndPoints {
    vehicleData: string;
}
