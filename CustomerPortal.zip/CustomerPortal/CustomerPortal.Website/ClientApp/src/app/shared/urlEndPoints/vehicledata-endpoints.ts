export const VehicleDataEndPoints = {
    vehicleData: 'api/vehicle/getinfo',
};
