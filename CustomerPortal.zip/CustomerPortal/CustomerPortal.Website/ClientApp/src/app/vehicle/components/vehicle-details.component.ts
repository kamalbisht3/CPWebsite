import { Component, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { VehicleDetailResponse } from '../../shared/models/vehicledetailresponse';
import { Culture } from '../../shared/models/culture';
import { CommonLabelHandlerService } from '../../shared/services/commonlabel-handler.service';
import { InternalizationService } from '../../shared/services/internalization.service';
import { VehicleDetailLabelTextConstants } from '../../shared/constants/vehicle-label-text';
import { OptionsHandlerService } from '../../shared/services/options-handler.service';

import { QuestionsEnum } from '../enums/questions.enum';


@Component({
    selector: 'app-vehicle-details',
    templateUrl: './vehicle-details.component.html',
    styleUrls: ['./vehicle-details.component.css']
})
export class VehicleDetailsComponent extends Culture implements OnInit {
    @Input() vehicleDetais: VehicleDetailResponse;
    @Input() index: number;
    @Input() otherInfo: any;
    coll: HTMLCollection;
    QuestionsEnum = QuestionsEnum;
    constructor(private optionsHandlerService: OptionsHandlerService, commonLabelHandlerService: CommonLabelHandlerService, internalizationService: InternalizationService, changeDetection: ChangeDetectorRef) {
        super(internalizationService, changeDetection, commonLabelHandlerService);
    }
    VehicleDetailLabelTextConstants = VehicleDetailLabelTextConstants;

    ngOnInit() {
        this.coll = document.getElementsByClassName("collapsible");
        super.cultureInitiallizer();
    }

    collapseAndExpand() {
        for (var i = 0; i < this.coll.length; i++) {
            this.coll[i].classList.remove("active");
            var content = this.coll[i].nextElementSibling as HTMLElement;
                content.style.maxHeight = null;
        }
        this.coll[this.index].classList.add("active");
        var displayContent = this.coll[this.index].nextElementSibling as HTMLElement;
        displayContent.style.maxHeight = content.scrollHeight + "px";
    }

    getOption(questionId: number, lookupId: number) {
        return this.optionsHandlerService.GetOptionValue(questionId, lookupId, this.currentCulture);
    }
}
