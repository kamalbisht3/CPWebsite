export enum QuestionsEnum {
    VehicleUsage = 39,
    TransmissionType = 42
}
