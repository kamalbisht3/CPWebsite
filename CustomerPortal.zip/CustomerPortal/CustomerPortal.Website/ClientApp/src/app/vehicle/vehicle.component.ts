import { Component, OnInit } from '@angular/core';
import { VehicleDataHandlerService } from '../shared/services/vehicledata-handler.service';
import { VehicleDetailResponse } from '../shared/models/vehicledetailresponse';
import { PolicyDataHandlerService } from '../shared/services/policy-handler.service';
import { policydetailResponse } from '../shared/models/policydetailresponse';

@Component({
    selector: 'app-vehicles',
    templateUrl: './vehicle.component.html',
    styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {
    vehiclesInfo: VehicleDetailResponse[];
    policyInfo: policydetailResponse[];
    otherInfo: any[] = [];

    constructor(private vehicleDataHandlerService: VehicleDataHandlerService, private policyDataHandlerService: PolicyDataHandlerService) { }

    ngOnInit() {
        this.vehiclesInfo = this.vehicleDataHandlerService.GetVehicleInfo();
        this.policyInfo = this.policyDataHandlerService.GetPolicyInfo();
        this.getOtherInfo();
    }

    getOtherInfo() {
        this.policyInfo.forEach(data => {
            var risk = JSON.parse(data.risk).ContractType.Vehicle;
            this.otherInfo.push(risk);
        });
    }

}
