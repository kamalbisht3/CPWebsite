import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VehicleRoutingModule } from './vehicle-routing.module';
import { VehicleComponent } from './vehicle.component';
import { VehicleDetailsComponent } from './components/vehicle-details.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [
        CommonModule,
        VehicleRoutingModule,
        SharedModule
    ],
    declarations: [
        VehicleComponent,
        VehicleDetailsComponent
    ],
    providers: [],
    exports: []
})
export class VehicleModule { }
