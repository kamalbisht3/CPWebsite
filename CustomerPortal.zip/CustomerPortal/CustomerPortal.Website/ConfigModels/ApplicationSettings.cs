﻿namespace Mena.CustomerPortal.Website.ConfigModels
{
    public class ApplicationSettings
    {
        public string CjWebUrl { get; set; }
        public int FileSizeLimit { get; set; }
        public int MaxFileAllowed { get; set; }

        public int MaxRequestLength { get
            {
                return FileSizeLimit * MaxFileAllowed;
            }
        }

    }
}
