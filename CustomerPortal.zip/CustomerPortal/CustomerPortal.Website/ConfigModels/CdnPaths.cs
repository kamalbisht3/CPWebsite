﻿namespace Mena.CustomerPortal.Website.ConfigModel
{
    public class CdnPaths
    {
        public string CdnCssPath { get; set; }
        public string CdnDistBundlePath { get; set; }
        public string CdnDomain { get; set; }
        public string CdnImagePath { get; set; }
        public string CdnJsPath { get; set; }
        public string CdnTrackerJsPath { get; set; }
        public string CssPath { get; set; }
        public string DistBundlePath { get; set; }
        public string ImagePath { get; set; }
        public string IsCdnActive { get; set; }
        public string JsPath { get; set; }
        public string TrackerUrl { get; set; }
    }

}
