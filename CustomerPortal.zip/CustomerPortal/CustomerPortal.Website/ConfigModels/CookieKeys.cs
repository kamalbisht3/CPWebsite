namespace Mena.CustomerPortal.Website.ConfigModel
{
  public class CookieKeys
  {
    public string GAActivityId { get; set; }
    public string GASessionId { get; set; }
    public string ActivityId { get; set; }
    public string SessionId { get; set; }
    public string UserTrackerId { get; set; }
    public string IsSessionTrackingEntryRequired { get; set; }
    public string ProductType { get; set; }

    public  string QuoteTemplate { get; set; }

    public  string CookieDomainName { get; set; }
    public  string CJSession { get; set; }
    public  string GASession { get; set; }
    public  string TimeOut { get; set; }

    public  string PreviousQuoteInfo { get; set; }

    public  string UserTracker { get; set; }

    public  string Day { get; set; }
    public  string Month { get; set; }
    public  string Year { get; set; }
    public  string Hour { get; set; }
    public  string Minute { get; set; }
    public  string Second { get; set; }
  }
}
