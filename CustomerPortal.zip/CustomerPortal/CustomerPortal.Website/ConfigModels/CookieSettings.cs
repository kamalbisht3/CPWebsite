namespace Mena.CustomerPortal.Website.ConfigModel
{
  public class CookieSettings
  {
    public string CookieName { get; set; }
    public string Domain { get; set; }
  }
}
