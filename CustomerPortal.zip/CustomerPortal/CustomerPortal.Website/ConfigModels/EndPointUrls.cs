﻿namespace Mena.CustomerPortal.Website.ConfigModel
{
    public class EndPointUrls
    {

        public string HttpWebHostUrl { get; set; }
        public string LookUpWebAPI { get; set; }
        public string CustomerPortalAPI { get; set; }
        public string CommonEmailerAPI { get; set; }


    }

}
