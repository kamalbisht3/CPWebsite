namespace Mena.CustomerPortal.Website.ConfigModel
{
    public class SessionKeys
    {
        public string ActivityId { get; set; }
        public string GAActivityId { get; set; }
        public string GASessionId { get; set; }
        public string SessionId { get; set; }
        public string UserTrackerId { get; set; }
        public string PageId { get; set; }
        public string SessionTracker { get; set; }
        public string CustomerId { get; set; }
        public string Risk { get; set; }
        public string OldRisk { get; set; }
        public string PrivacyData { get; set; }
        public string OldPrivacyData { get; set; }
        public string UserDetail { get; set; }
        public string QuotesData { get; set; }
        public string ClickType { get; set; }
        public string ExtendedInfo { get; set; }
        public string IsCJCompleted { get; set; }
        public string SelectedCoverType { get; set; }
        public string WaitPageQuestionInserted { get; set; }
        public string LandbackClickType { get; set; }
        public string LandBackQrn { get; set; }
        public string IsCtrClicked { get; set; }
        public string Is30SecondSurveyFiledByUser { get; set; }
        public string IsEmailSent { get; set; }
        public string ActivitySourceType { get; set; }
        public string RevisitedAcitivity { get; set; }
        public string PaymentClosingACID { get; set; }
        public string IsAutoCmbDone { get; set; }
        public string IsAnyLeadCreated { get; set; }
        public string PersoanlInfo { get; set; }
        public string VehicleInfo { get; set; }
        public string isAuthenticated { get; set; }
        public string Email { get; set; }
        public string UserRisk { get; set; }
    }
}
