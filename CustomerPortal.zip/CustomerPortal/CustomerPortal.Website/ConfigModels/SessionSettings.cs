namespace Mena.CustomerPortal.Website.ConfigModel
{
  public class SessionSettings
  {
    public string ApplicationDiscriminator { get; set; }
    public string ApplicationName { get; set; }
    public int IsSessionExpiry { get; set; }
    public string ProtectionKey { get; set; }
    public int SessionTimeout { get; set; }
    public string TrackerUrl { get; set; }
  }
}
