﻿namespace Mena.CustomerPortal.Website.Constants
{
    using Mena.Components.Constants;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public static class ApiEndpointUrls
    {

        public static string LookUpWebApi;
        public static string CustomerPortalAPI;
        public static string CommonEmailerAPI;

        public static string LookUpCommonLabels => LookUpWebApi + "/api/Label/GetCommanLabelText/" + ProductCode.CustomerPortal;
        public static string LookUpOptions => LookUpWebApi + "/api/Option/GetOptions/" + ProductCode.Motor;
        public static string AuthIdentity => CustomerPortalAPI + "/api/customer/Auth/loginvalidate";
        public static string ForgotIdentity => CustomerPortalAPI + "/api/customer/Auth/createforgotlink";
        public static string CommonEmailer => CommonEmailerAPI + "/api/CommonEmailer/send";
        public static string VehicleData => CustomerPortalAPI + "/api/customer/Vehicle/info";
        public static string PolicyData => CustomerPortalAPI + "/api/customer/policyinfo/details";

        public static string ValidateForgotIdentity => CustomerPortalAPI + "/api/customer/Auth/validateforgotlink";
        public static string ResetIdentity => CustomerPortalAPI + "/api/customer/Auth/resetpassword";
        public static string GetPersonalInfo => CustomerPortalAPI + "/api/customer/Personal/personalinfo";
        public static string GetQuoteHistory => CustomerPortalAPI + "/api/customer/QuoteHistory/details";
        public static string UploadFileInsert => CustomerPortalAPI + "/api/customer/File/UploadFile";
        public static string GetUploadedFile => CustomerPortalAPI + "/api/customer/File/GetUploadedFile";
        public static string DeleteImageFile => CustomerPortalAPI + "/api/customer/File/deletefile";
    }
}
