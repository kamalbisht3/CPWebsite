﻿namespace Mena.CustomerPortal.Website.Controllers
{
    using System;
    using System.Text;
    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Enums;
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    //using Mena.Apis.Identity.Contracts.Enums;
    //using Mena.Apis.Identity.Contracts.Models;
    using Mena.Communication.Email.Contracts;
    using Mena.Components.Constants;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.ConfigModel;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Helpers;
    using Mena.CustomerPortal.Website.Models;
    using Mena.CustomerPortal.Website.Providers;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    [Route("api/[controller]")]
    public class AuthController : BaseController
    {
        private IRestProxy _restProxy { get; }

        private EndPointUrls _endPointUrls;

        private EmailSenderConfig _emailSenderConfig;

        // GET: /<controller>/
        public AuthController(ILogger logger, IWebSession webSession, IRestProxy restProxy, IOptions<EndPointUrls> endPoints, IOptions<EmailSenderConfig> emailSender) : base(logger, webSession)
        {
            _endPointUrls = endPoints.Value;
            _restProxy = restProxy;
            _emailSenderConfig = emailSender.Value;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody]LoginModel loginModel)
        {
            if (ModelState.IsValid)
            {
                //if(loginModel.Email == "wakeel@test.com" && loginModel.Password == "1234")
                //{
                //    return Json(new JsonSuccessWrapper<UserModel>(new UserModel {  Email=loginModel.Email, Name="Wakeel User"}));
                //}
                var url = ApiEndpointUrls.AuthIdentity;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<LoginValidateResult>, LoginValidateRequest>(url, new LoginValidateRequest { EmailAddress = loginModel.Email, Password = loginModel.Password });
                if (_result != null)
                {
                    if (_result.Response.UserAccountStatus == LoginValidateStatus.Valid)
                    {
                        await UserSession.IsUserAuthenticated(true);
                        await UserSession.Email(loginModel.Email);
                    }
                    else
                    {
                        await UserSession.IsUserAuthenticated(false);
                    }
                    return Ok(_result.Response);
                }
            }
            return Json(new JsonNotFoundWrapper());
        }


        [HttpGet("isuserauthenticated")]
        public async Task<bool> UserAuthenticationStatus()
        {
            return await UserSession.IsUserAuthenticated();
        }

        [HttpGet("userlogout")]
        public async Task UserLogoutStatus()
        {
            await UserSession.IsUserAuthenticated(false);
        }


        [HttpPost("forgot")]
        public async Task<IActionResult> ForgotLinkSend([FromBody]ForgotPasswordModel forgotPasswordModel)
        {
            if (ModelState.IsValid)
            {
                var url = ApiEndpointUrls.ForgotIdentity;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<ForgotLinkResult>, ForgotLinkRequest>(url, new ForgotLinkRequest { EmailAddress = forgotPasswordModel.Email });
                if (_result.Response.Status == ForgotLinkCreateStaus.Value)
                {
                    await SendMailToUser(forgotPasswordModel, _result.Response);

                    return Json(new JsonSuccessWrapper<int>((int)_result.Response.Status));

                }

            }
            return Json(new JsonNotFoundWrapper());
        }

        [HttpPost("UpdatePassword")]
        public async Task<IActionResult> ResetPassword([FromBody]UpdatePasswordModel updatePasswordModel)
        {
            if (ModelState.IsValid)
            {
                var url = ApiEndpointUrls.ResetIdentity;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<PasswordResetResult>, PasswordResetRequest>(url, new PasswordResetRequest { EmailAddress = null, Password = updatePasswordModel.Password });

                if (_result.Status)
                {

                    //get commonlabel for both langage
                    return Json(_result);
                }
            }

            return Json(new JsonNotFoundWrapper());

        }

        [HttpPost("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody]ChangePasswordModel changePasswordModel)
        {
            if (ModelState.IsValid)
            {

                if (await UserSession.IsUserAuthenticated())
                {
                    string EmailId = await UserSession.Email();
                    var url = ApiEndpointUrls.ResetIdentity;
                    var _result = await _restProxy.PostAsync<JsonSuccessWrapper<PasswordResetResult>, PasswordResetRequest>(url, new PasswordResetRequest { Password = changePasswordModel.NewPassword, EmailAddress = EmailId });

                    if (_result.Status)
                    {
                        //get commonlabel for both langage
                        return Json(_result);
                    }
                }
            }

            return Json(new JsonNotFoundWrapper());
        }



        private static string emailTemplate = @"<!DOCTYPE html><html><head> <meta charset=""utf-8""> <meta http-equiv=""x-ua-compatible"" content=""ie=edge""> <title>Password Reset</title> <meta name=""viewport"" content=""width=device-width, initial-scale=1""> <style type=""text/css""> /*  Google webfonts. Recommended to include the .woff version for cross-client compatibility. / @media screen{@font-face{font-family: 'Source Sans Pro'; font-style: normal; font-weight: 400; src: local('Source Sans Pro Regular'), local('SourceSansPro-Regular'), url(https://fonts.gstatic.com/s/sourcesanspro/v10/ODelI1aHBYDBqgeIAH2zlBM0YzuT7MdOe03otPbuUS0.woff) format('woff');}@font-face{font-family: 'Source Sans Pro'; font-style: normal; font-weight: 700; src: local('Source Sans Pro Bold'), local('SourceSansPro-Bold'), url(https://fonts.gstatic.com/s/sourcesanspro/v10/toadOcfmlt9b38dHJxOBGFkQc6VGVFSmCnC_l7QZG60.woff) format('woff');}}/*  Avoid browser level font resizing.  1. Windows Mobile  2. iOS / OSX / body, table, td, a{-ms-text-size-adjust: 100%; / 1 / -webkit-text-size-adjust: 100%; / 2 /}/*  Remove extra space added to tables and cells in Outlook. / table, td{mso-table-rspace: 0pt; mso-table-lspace: 0pt;}/*  Better fluid images in Internet Explorer. / img{-ms-interpolation-mode: bicubic;}/*  Remove blue links for iOS devices. / a[x-apple-data-detectors]{font-family: inherit !important; font-size: inherit !important; font-weight: inherit !important; line-height: inherit !important; color: inherit !important; text-decoration: none !important;}/*  Fix centering issues in Android 4.4. / div[style*=""margin: 16px 0;""]{margin: 0 !important;}body{width: 100% !important; height: 100% !important; padding: 0 !important; margin: 0 !important;}/*  Collapse table borders to avoid space between cells. */ table{border-collapse: collapse !important;}a{color: #1a82e2;}img{height: auto; line-height: 100%; text-decoration: none; border: 0; outline: none;}</style></head><body style=""background-color: #e9ecef;""> <div class=""preheader"" style=""display: none; max-width: 0; max-height: 0; overflow: hidden; font-size: 1px; line-height: 1px; color: #fff; opacity: 0;""> Reset Password @ Wakkel.com </div><table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%""> <tr> <td align=""center"" bgcolor=""#e9ecef""><!--[if (gte mso 9)|(IE)]> <table align=""center"" border=""0"" cellpadding=""0"" cellspacing=""0"" width=""600""> <tr> <td align=""center"" valign=""top"" width=""600""><![endif]--> <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"" style=""max-width: 600px;""> <tr> <td align=""center"" valign=""top"" style=""padding: 36px 24px;""> <a href=""https://wakeel.com"" target=""_blank"" style=""display: inline-block; font-size:30px; text-decoration:none; font-weight:bold; color:#4dbdec""> Wakeel.com </a> </td></tr></table><!--[if (gte mso 9)|(IE)]> </td></tr></table><![endif]--> </td></tr><tr> <td align=""center"" bgcolor=""#e9ecef""><!--[if (gte mso 9)|(IE)]> <table align=""center"" border=""0"" cellpadding=""0"" cellspacing=""0"" width=""600""> <tr> <td align=""center"" valign=""top"" width=""600""><![endif]--> <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"" style=""max-width: 600px;""> <tr> <td align=""left"" bgcolor=""#ffffff"" style=""padding: 36px 24px 0; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; border-top: 3px solid #d4dadf;""> <h1 style=""margin: 0; font-size: 32px; font-weight: 700; letter-spacing: -1px; line-height: 48px;"">Reset Your Password</h1> </td></tr></table><!--[if (gte mso 9)|(IE)]> </td></tr></table><![endif]--> </td></tr><tr> <td align=""center"" bgcolor=""#e9ecef""><!--[if (gte mso 9)|(IE)]> <table align=""center"" border=""0"" cellpadding=""0"" cellspacing=""0"" width=""600""> <tr> <td align=""center"" valign=""top"" width=""600""><![endif]--> <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"" style=""max-width: 600px;""> <tr> <td align=""left"" bgcolor=""#ffffff"" style=""padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;""> <p style=""margin: 0;"">{forgetmessage}</p></td></tr><tr> <td align=""left"" bgcolor=""#ffffff""> <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%""> <tr> <td align=""center"" bgcolor=""#ffffff"" style=""padding: 12px;""> <table border=""0"" cellpadding=""0"" cellspacing=""0""> <tr> <td align=""center"" bgcolor=""#1a82e2"" style=""border-radius: 6px; width: 188px;height:47px;""> <a href=""{forgetlink}"" target=""_blank"" style=""display: inline-block; padding: 16px 36px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; border-radius: 6px; padding:10px !important"">Reset Password</a> </td></tr></table> </td></tr></table> </td></tr><tr> <td align=""left"" bgcolor=""#ffffff"" style=""padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;""> <p style=""margin: 0;"">If that doesn't work, copy and paste the following link in your browser:</p><p style=""margin: 0;""><a href=""{forgetlink}"" target=""_blank""><small>{forgetlink}</small></a></p></td></tr><tr> <td align=""left"" bgcolor=""#ffffff"" style=""padding: 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px; border-bottom: 3px solid #d4dadf""> <p style=""margin: 0;"">Cheers</p></td></tr></table><!--[if (gte mso 9)|(IE)]> </td></tr></table><![endif]--> </td></tr><tr> <td align=""center"" bgcolor=""#e9ecef"" style=""padding: 24px;""><!--[if (gte mso 9)|(IE)]> <table align=""center"" border=""0"" cellpadding=""0"" cellspacing=""0"" width=""600""> <tr> <td align=""center"" valign=""top"" width=""600""><![endif]--> <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"" style=""max-width: 600px;""> <tr> <td align=""center"" bgcolor=""#e9ecef"" style=""padding: 12px 24px; font-family: 'Source Sans Pro', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px; color: #666;""> <p style=""margin: 0;"">You received this email because we received a request for reset password for your account. If you didn't request reset password, you can safely delete this email.</p></td></tr></table><!--[if (gte mso 9)|(IE)]> </td></tr></table><![endif]--> </td></tr></table> </body></html>";

        private async Task<IActionResult> SendMailToUser(ForgotPasswordModel request, ForgotLinkResult data)
        {

            var forgetLink = _endPointUrls.HttpWebHostUrl + "/ResetPassword/" + data.ResultSet;

            var template = emailTemplate.Replace("{forgetlink}", forgetLink).Replace("{forgetmessage}", request.ForgotMessage ?? "Please click on the following link to reset your password");


            var emailInfo = new EmailData
            {
                Email = request.Email,
                HeaderText = _emailSenderConfig.HeaderText,
                BCC = _emailSenderConfig.BCC,
                Subject = _emailSenderConfig.Subject,
                CC = _emailSenderConfig.CC,
                Priority = _emailSenderConfig.Priority,
                SenderDisplayName = _emailSenderConfig.SenderDisplayName,
                TemplateInfo = new TemplateInfo
                {
                    TemplateId = null,
                    TemplateBody = template,
                    PlaceholderValues = null
                }

            };
            var _result = await _restProxy.PostAsync<JsonSuccessWrapper<ForgotLinkResult>, EmailData>(ApiEndpointUrls.CommonEmailer, emailInfo);

            return Json(_result);


        }

        //private void SendMail(string body, string email, string subject)
        //{
        //    body = body + Environment.NewLine;
        //    _mailSender.SendMail(body, email, subject).FireAndForget(false, (ex) =>
        //    {
        //        Log(ex + ex.StackTrace, ProductCode.Bike, LogCategory.CodeLogic, "AuthController", "CustomerPortal-SendMail");

        //    });
        //}
    }
}
