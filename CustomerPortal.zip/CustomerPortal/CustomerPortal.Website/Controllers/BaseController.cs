namespace Mena.CustomerPortal.Website.Controllers
{
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.Session;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class BaseController : MvcBaseController<CustomerSession>
    {


        public BaseController(ILogger logger, IWebSession webSession) : base(logger, webSession)
        {

        }

        public string SetIpAddress(string ipAddress)
        {
            var serverIp = ipAddress.ToLower();
            var splittedArray = new List<string>();
            var specialCharacter = string.Empty;
            if (serverIp.Contains(":"))
            {
                splittedArray = serverIp.Split(":").ToList();
                specialCharacter = ":";
            }
            else if (serverIp.Contains("-"))
            {
                splittedArray = serverIp.Split("-").ToList();
                specialCharacter = "-";
            }
            else if (serverIp.Contains("."))
            {
                splittedArray = serverIp.Split(".").ToList();
                specialCharacter = ".";
            }
            if (splittedArray.Count == 5)
            {
                serverIp = String.Join(specialCharacter, splittedArray.Skip(3).Take(2));
            }
            else if (splittedArray.Count == 4)
            {
                serverIp = String.Join(specialCharacter, splittedArray.Skip(2).Take(2));
            }
            return serverIp;
        }


    }
}
