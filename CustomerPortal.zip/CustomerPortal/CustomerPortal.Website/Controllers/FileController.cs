﻿namespace Mena.CustomerPortal.Website.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Enums;
    using Mena.Apis.CustomerPortal.Contracts.Request.File;
    using Mena.Apis.CustomerPortal.Contracts.Response.File;
    using Mena.Components.Constants;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.Attributes;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Controllers;
    using Mena.CustomerPortal.Website.Models;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Mena.Apis.CustomerPortal.Contracts.Request.File;
    using Mena.Apis.CustomerPortal.Contracts.Response.File;
    using Mena.Components.Web.Core.Mvc;
    using System.IO;
    using Mena.CustomerPortal.Website.Constants;

    [Route("api/[controller]")]
    public class FileController : BaseController
    {
        private IRestProxy _restProxy { get; }
        public FileController(ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            _restProxy = restProxy;
        }

        [HttpPost("upload")]
        [ServiceFilter(typeof(RequestSizeLimitConfAttribute))]
        public async Task<IActionResult> UploadAsync([FromForm] FileModel fileModel)
        {
            if (fileModel?.File.Count == 0)
                return Json(new JsonBadRequestWrapper(new[] { "No files in request." }));

            var requestList = new List<FileInsertRequest>();


            foreach (var file in fileModel.File)
            {
                if (file?.Length > 0)
                {
                    byte[] fileData = null;

                    using (var streamReader = new MemoryStream())
                    {
                        await file.CopyToAsync(streamReader);

                        if (streamReader.Length > 0)
                        {
                            if (streamReader.CanSeek)
                            {
                                streamReader.Position = 0;
                            }

                            fileData = streamReader.ToArray();
                        }
                    }

                    if (fileData?.Length > 0)
                    {
                        var fileInsertRequest = new FileInsertRequest
                        {
                            EmailAddress = await UserSession.Email(),
                            Data = fileData
                        };

                        //fileInsertRequest.Data = fileData.ToArray();

                        requestList.Add(fileInsertRequest);
                    }

                }

            }

            var _result = await _restProxy.PostAsync<JsonSuccessWrapper<int>, List<FileInsertRequest>>(ApiEndpointUrls.UploadFileInsert, requestList);

            if (_result.Status)
            {
                // Log("File Uploaded and saved in db Successfully", ProductCode.Motor, LogCategory.InternalServiceCall);
                return Ok(_result.Response);
            }

            return Json(new JsonNotFoundWrapper());

        }
        [HttpGet("getUploadedImage")]
        public async Task<IActionResult> GetUploadedImageAsync()
        {
            var url = ApiEndpointUrls.GetUploadedFile;

            var fileGetRequest = new FileGetRequest
            {
                EmailAddress = await UserSession?.Email()
            };
            var _result = await _restProxy.PostAsync<JsonSuccessWrapper<List<FileGetResult>>, FileGetRequest>(url, fileGetRequest);

            if (_result.Status)
            {
                return Ok(_result.Response);
            }
            return Json(new JsonNotFoundWrapper());
        }

        [HttpPost("deleteImage")]
        public async Task<IActionResult> DeleteImageAsync([FromBody] FileDeleteModel fileDeleteModel)
        {
            var url = ApiEndpointUrls.DeleteImageFile;
            var fileDeleteRequest = new FileDeleteRequest
            {
                UploadimageDataID = fileDeleteModel.ImageId,
                EmailID = await UserSession?.Email()
            };

            var _result = await _restProxy.PostAsync<JsonSuccessWrapper<int>, FileDeleteRequest>(url, fileDeleteRequest);
            if (_result.Status)
                return Ok(_result.Response);

            return Json(new JsonNotFoundWrapper());

        }
    }
}