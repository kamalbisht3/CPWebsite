﻿namespace Mena.CustomerPortal.Website.Controllers
{
    using System.Threading.Tasks;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.Models;
    using Mena.CustomerPortal.Website.Constants;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using Mena.Components.Constants;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;

    [Route("api/[controller]")]
    public class OptionController : BaseController
    {
        private IRestProxy _restProxy { get; }
        public OptionController(ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            _restProxy = restProxy;
        }

     

        [HttpGet("alloptions")]
        public async Task<IActionResult> AllOption()
        {
            //var result = string.Empty;
            try
            {
                var url = ApiEndpointUrls.LookUpOptions;
                var result = await _restProxy.GetAsync<object>(url);
                if (result != null)
                {
                    //TempData["Commonlabel"] = result;
                    return Json(result);
                }
            }
            catch (Exception ex)
            {
                Log(ex, ProductCode.Motor, LogCategory.InternalServiceCall);
                //  DebugLog.Log(ex);
            }
            return NotFound();
        }

    }
}
