﻿namespace Mena.CustomerPortal.Website.Controllers
{

    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Enums;
    using Mena.Apis.CustomerPortal.Contracts.Request.Personal;
    using Mena.Apis.CustomerPortal.Contracts.Response.Personal;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.ConfigModel;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Helpers;
    using Mena.CustomerPortal.Website.Models;
    using Mena.CustomerPortal.Website.Providers;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    [Route("api/[controller]")]
    public class PersonalController : BaseController
    {
        private IRestProxy _restProxy { get; }


        // GET: /<controller>/
        public PersonalController(ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            _restProxy = restProxy;  
        }

        [HttpGet("personaldetail")]
        public async Task<IActionResult> PersonalDetail()
        {
            if (ModelState.IsValid)
            {
                if (await UserSession.IsUserAuthenticated())
                {
                    var personal = new PersonalDetailRequest
                    {
                        EmailAddress = await UserSession.Email()
                    };
                    var url = ApiEndpointUrls.GetPersonalInfo;
                    var _result = await _restProxy.PostAsync<JsonSuccessWrapper<PersonalDetailResult>, PersonalDetailRequest>(url, personal);
                    if (_result != null)
                    {
                        return Ok(_result.Response);
                    }
                }
            }
            return Json(new JsonNotFoundWrapper());
        }


    }
}
