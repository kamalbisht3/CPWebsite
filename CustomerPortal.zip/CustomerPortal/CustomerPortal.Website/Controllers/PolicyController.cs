﻿namespace CustomerPortal.Website.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Request.Policy;
    using Mena.Apis.CustomerPortal.Contracts.Response.Policy;
    using Mena.Components.Constants;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Controllers;
    using Mena.CustomerPortal.Website.Models;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/[controller]")]
    public class PolicyController : BaseController
    {
        private IRestProxy _restProxy { get; }
        public PolicyController(ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            _restProxy = restProxy;
        }

        [HttpGet("getinfo")]
        public async Task<IActionResult> GetPolicyDetails()
        {
            if (await UserSession.IsUserAuthenticated())
            {
                var policy = new PolicyInfoRequest
                {
                    Email = await UserSession.Email()
                };
                var url = ApiEndpointUrls.PolicyData;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<List<PolicyInformation>>, PolicyInfoRequest>(url, policy);
                if (_result != null)
                {
                    return Ok(_result.Response);
                }
            }
            return Json(new JsonNotFoundWrapper());
        }
    }
}