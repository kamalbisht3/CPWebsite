﻿namespace CustomerPortal.Website.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Apis.CustomerPortal.Contracts.Request.QuoteHistory;
    using Mena.Apis.CustomerPortal.Contracts.Response.QuoteHistory;
    using Mena.Components.Constants;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Controllers;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/[controller]")]
    public class QuoteHistoryController : BaseController
    {
        private IRestProxy _restProxy { get; }
        public QuoteHistoryController(ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            _restProxy = restProxy;
        }

        [HttpGet("details")]
        public async Task<IActionResult> GetQuoteHistoryDetails()
        {
            if (await UserSession.IsUserAuthenticated())
            {
                var quote = new QuoteHistoryRequest
                {
                    Email = await UserSession.Email()
                };
                var url = ApiEndpointUrls.GetQuoteHistory;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<List<QuoteHistory>>, QuoteHistoryRequest>(url, quote);
                if (_result != null)
                {
                    return Ok(_result.Response);
                }
            }
            return Json(new JsonNotFoundWrapper());
        }
    }
}