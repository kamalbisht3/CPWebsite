﻿namespace Mena.CustomerPortal.Website.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.CustomerPortal.Website.Controllers;
    using Microsoft.AspNetCore.Mvc;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;
    using Mena.Components.Constants;
    using Mena.Apis.CustomerPortal.Contracts.Request.Vehicle;
    using Mena.Components.Web.Core.Mvc;
    using Mena.Apis.CustomerPortal.Contracts.Response.Vehicle;

    [Route("api/[controller]")]
    public class VehicleController : BaseController
    {
        private IRestProxy _restProxy { get; }
        public VehicleController(ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            _restProxy = restProxy;
        }

        [HttpGet("getinfo")]
        public async Task<IActionResult> GetVehicleDetails()
        {
            if (await UserSession.IsUserAuthenticated())
            {
                var vehicleInfo = new VehicleRequest
                {
                    Email = await UserSession.Email()
                };
                var url = ApiEndpointUrls.VehicleData;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<List<VehicleInfo>>, VehicleRequest>(url, vehicleInfo);
                if (_result != null)
                {
                    return Ok(_result.Response);
                }
            }
            return Json(new JsonNotFoundWrapper());
        }
    }
}