﻿namespace Mena.CustomerPortal.Website.Attributes
{
    using Mena.CustomerPortal.Website.ConfigModels;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using System;

    public class RequestSizeLimitConfAttribute : RequestSizeLimitAttribute
    {
        public RequestSizeLimitConfAttribute(IOptions<ApplicationSettings> options) : base(options?.Value.MaxRequestLength ?? 4194304) { }
    }
}
