namespace Mena.CustomerPortal.Website.Helpers
{
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts.Enums;
    using Mena.Components.Web.Core.Contracts.Session;
    using Microsoft.AspNetCore.Mvc.RazorPages;
    using System;
    using System.Diagnostics;

    public class BasePageModel<T> : PageModel where T : class, IWebSession
    {
        public ILogger Logger
        {
            get;
        }

        public T UserSession
        {
            get;
            private set;
        }

        public BasePageModel(ILogger logger, IWebSession session)
        {
            Logger = logger;
            UserSession = (session as T);
        }

        public virtual void Log(Exception ex, int product, LogCategory category, string pageName = null, string pageUrl = null, string customMessage = null, Guid? sessionId = default(Guid?), Guid eventId = default(Guid))
        {
            Logger.Log(ex, customMessage ?? ex.Message, product, category, pageName, pageUrl, TraceEventType.Error, sessionId ?? Guid.Empty, eventId);
        }

        public virtual void Log(string message, int product, LogCategory category, string pageName = null, string pageUrl = null, Guid? sessionId = default(Guid?), Guid eventId = default(Guid))
        {
            Logger.Log(message, product, category, pageName, pageUrl, TraceEventType.Information, sessionId ?? Guid.Empty, eventId);
        }
    }
}
