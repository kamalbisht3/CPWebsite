namespace Mena.CustomerPortal.Website.Helpers
{
  using System;

  public static class DebugLog
  {
    public static void Log(Exception ex)
    {
#if DEBUG
      Console.Write(ex.Message);
#endif
    }
  }
}
