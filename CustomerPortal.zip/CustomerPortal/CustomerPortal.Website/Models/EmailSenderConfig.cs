﻿namespace Mena.CustomerPortal.Website.Models
{
    using Mena.Communication.Email.Contracts;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// EmailSender
    /// </summary>
    public class EmailSenderConfig
    {

        public string Subject { get; set; }

        public string[] BCC { get; set; }

        public string HeaderText { get; set; }

        public string[] CC { get; set; }

        public MessagePriority Priority {get;set;}

        public string SenderDisplayName { get; set; }

        public TemplateInfo TemplateInfo { get; set; }

        public IEmailAttachment[] Attachments { get; set; }
    }
}
