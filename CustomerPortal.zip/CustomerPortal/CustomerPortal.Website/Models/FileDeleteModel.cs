﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mena.CustomerPortal.Website.Models
{
    public class FileDeleteModel
    {
        public long ImageId { get; set; }
    }
}
