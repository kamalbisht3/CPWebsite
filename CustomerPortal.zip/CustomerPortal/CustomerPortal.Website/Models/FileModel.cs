﻿namespace Mena.CustomerPortal.Website.Models
{
    using Microsoft.AspNetCore.Http;
    using System.Collections.Generic;

    public class FileModel
    {
        public List<IFormFile> File { get; set; }
    }
}
