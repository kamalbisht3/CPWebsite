﻿namespace Mena.CustomerPortal.Website.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading.Tasks;

    public class LoginModel
    {
        [EmailAddress(ErrorMessage = "1")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password, ErrorMessage = "2")]
        public string Password { get; set; }
    }
}
