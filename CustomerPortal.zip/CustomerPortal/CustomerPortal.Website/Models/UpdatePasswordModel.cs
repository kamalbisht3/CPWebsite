﻿namespace Mena.CustomerPortal.Website.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading.Tasks;

    public class UpdatePasswordModel
    {
        //[Required]
        //[EmailAddress]
        //public string Email { get; set; }


        [StringLength(12, ErrorMessage = "Password must be between 6 to 12 char",MinimumLength = 6)]
        //[RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\da-zA-Z]).{6,12}$", ErrorMessage = "Invalid password format")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Password is required.")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "Password and Confirmation Password doesn't match.")]
        [Required(ErrorMessage = "Confirmation Password is required.")]
        public string ConfirmPassword { get; set; }
    }
}
