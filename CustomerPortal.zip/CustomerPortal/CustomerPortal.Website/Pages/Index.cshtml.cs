﻿namespace Mena.CustomerPortal.Website.Pages
{
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.CustomerPortal.Website.ConfigModel;
    using Mena.CustomerPortal.Website.Helpers;
    using Mena.CustomerPortal.Website.Session;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public class IndexModel : BasePageModel<CustomerSession>
    {
        private readonly CdnPaths cdnPaths;
        public IndexModel(IOptions<CdnPaths> _cdnPaths, ILogger logger, IWebSession webSession) : base(logger, webSession)
        {
            cdnPaths = _cdnPaths?.Value;
        }

        public void OnGet()
        {
            ViewData["DistBundlePath"] = cdnPaths?.DistBundlePath;
            ViewData["TrackerUrl"] = cdnPaths?.TrackerUrl;
        }
    }
}
