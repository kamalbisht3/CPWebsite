﻿
namespace Mena.CustomerPortal.Website.Pages
{
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Apis.Identity.Contracts.Models;
    using Mena.Apis.Lookup.Contracts;
    using Mena.Components.Core.Extensions;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.ServiceProxy.Contracts;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Mvc;
    using Mena.CustomerPortal.Website.ConfigModel;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Helpers;
    using Mena.CustomerPortal.Website.Models;
    using Mena.CustomerPortal.Website.Session;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using System.Collections.Generic;
    using System.Threading.Tasks;


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    [IgnoreAntiforgeryToken(Order = 1001)]
    public class ResetPasswordModel : BasePageModel<CustomerSession>
    {
        [BindProperty]
        public UpdatePasswordModel Input { get; set; }

        private readonly CdnPaths cdnPaths;
        private IRestProxy _restProxy { get; }
        public ResetPasswordModel(IOptions<CdnPaths> _cdnPaths, ILogger logger, IWebSession webSession, IRestProxy restProxy) : base(logger, webSession)
        {
            cdnPaths = _cdnPaths?.Value;
            _restProxy = restProxy;
        }

        public async Task OnGet(string linkid = null)
        {
            ViewData["TrackerUrl"] = cdnPaths?.TrackerUrl;
            if (linkid != null)
            {

                var url = ApiEndpointUrls.ValidateForgotIdentity;
                var _result = await _restProxy.PostAsync<JsonSuccessWrapper<ForgotLinkValidResult>, ForgotLinkValidRequest>(url, new ForgotLinkValidRequest { Identifier = linkid });
                ViewData["Status"] = (int)_result.Response.Status;
                ViewData["ResultSet"] = (string)_result.Response.ResultSet;
                ViewData["IsPost"] = true;
            } else
            {
                ViewData["InvalidToken"] = "Invalid Token, Please contact to admin or try again.!!";
                ViewData["IsPost"] = false;
            }

            //get all common label from api, store in viewData as json format and render in page as input=hidden
            var urlPoint = ApiEndpointUrls.LookUpCommonLabels;
            var result = await _restProxy.GetAsync<JsonSuccessWrapper<List<LabelDetails>>>(urlPoint);
            
            if(result.Status)
            ViewData["CommonLabelsJson"] = result.Response?.ToJson();
   
        }

        //[Route("post")]
        //public async Task<string> OnPostAsync([FromBody]UpdatePasswordModel updatepasswordmodel)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var url = ApiEndpointUrls.ResetIdentity;
        //        var _result = await _restProxy.PostAsync<JsonSuccessWrapper<PasswordResetResult>, PasswordResetRequest>(url, new PasswordResetRequest { EmailAddress = null, Password = updatepasswordmodel.Password });
        //        ViewData["Status"] = (int)_result.Response.Status;
        //        ViewData["UpdateResultSet"] =(string)_result.Response.ResultSet;
        //        ViewData["IsPost"] = true;
        //        return Newtonsoft.Json.JsonConvert.SerializeObject(new { msg = _result.Response.ResultSet, status = true }) ;
        //    }
        //    //return ViewData["UpdateResultSet"];
        //    return Newtonsoft.Json.JsonConvert.SerializeObject(new { status = false });
        //    //return RedirectToAction("./OnGet");
        //    ///ModelState.Clear();
        //}


    }
}