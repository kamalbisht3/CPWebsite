namespace Mena.CustomerPortal.Website.Providers
{
  using System;
  using System.Diagnostics;
  using Mena.Components.Core.Instrumentation.Contracts;
  using Mena.Components.Core.Instrumentation.Contracts.Enums;
  using Mena.Components.Web.Core.Contracts.Session;

  public class BaseProvider<T> where T : class
  {
    public ILogger Logger
    {
      get;
    }

    public T UserSession
    {
      get;
      private set;
    }

    public BaseProvider(ILogger logger, IWebSession session)
    {
      Logger = logger;
      UserSession = (session as T);
    }
    public virtual void Log(Exception ex, int product, LogCategory category, string pageName = null, string pageUrl = null, string customMessage = null, Guid? sessionId = default(Guid?), Guid eventId = default(Guid))
    {
      Logger.Log(ex, customMessage ?? ex.Message, product, category, pageName, pageUrl, TraceEventType.Error, sessionId ?? Guid.Empty, eventId);
    }

    public virtual void Log(string message, int product, LogCategory category, string pageName = null, string pageUrl = null, Guid? sessionId = default(Guid?), Guid eventId = default(Guid))
    {
      Logger.Log(message, product, category, pageName, pageUrl, TraceEventType.Information, sessionId ?? Guid.Empty, eventId);
    }
  }
}
