namespace Mena.CustomerPortal.Website.Session
{
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Session;
    using Mena.CustomerPortal.Website.ConfigModel;
    using Mena.Motor.DataContracts.Request;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Options;
    using System;
    using System.Threading.Tasks;

    public class CustomerSession : DefaultSession
    {
        private readonly CookieKeys cookieKeys;
        private readonly SessionKeys sessionKeys;
        private readonly CookieSettings cookieSettings;
        public CustomerSession(ISessionInitializer sessionInitializer, IDeviceDetectionProvider deviceDetectionProvider, ISessionStoreProvider sessionProvider, ICookieStoreProvider cookieStoreProvider, IHttpContextAccessor httpContextAccessor, IOptions<CookieKeys> _cookieKeys, IOptions<SessionKeys> _sessionKeys, IOptions<CookieSettings> _cookieSettings) : base(sessionInitializer, deviceDetectionProvider, sessionProvider, cookieStoreProvider, httpContextAccessor)
        {
            cookieKeys = _cookieKeys.Value;
            sessionKeys = _sessionKeys.Value;
            cookieSettings = _cookieSettings.Value;
        }
        public override bool IsSessionExpired => string.IsNullOrEmpty(_cookieStoreProvider.Get(cookieKeys.SessionId));
        //public string ActivityId => _sessionStoreProvider.Get<string>(sessionKeys.ActivityId);

        /// <summary>
        /// Gets the session identifier.
        /// </summary>
        /// <value>
        /// The session identifier.
        /// </value>
        public string SessionId
        {

            get
            {
                var sessionIdValue = _sessionStoreProvider.Get<String>(sessionKeys.SessionId);

                return sessionIdValue == null || sessionIdValue.Equals(Guid.Empty) ? _cookieStoreProvider.Get(cookieKeys.SessionId) : sessionIdValue;

            }
        }

        /// <summary>
        /// Gets the user tracker session identifier.
        /// </summary>
        /// <value>
        /// The user tracker session identifier.
        /// </value>
        public string UserTrackerSessionId
        {
            get
            {
                return _sessionStoreProvider.Get<String>(sessionKeys.UserTrackerId) == default(Guid).ToString() || _sessionStoreProvider.Get<String>(sessionKeys.UserTrackerId) == null ? _cookieStoreProvider.Get(cookieKeys.UserTrackerId) : _sessionStoreProvider.Get<String>(sessionKeys.UserTrackerId);
            }
        }


        /// <summary>
        /// Gets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public short ProductId
        {
            get
            {
                return short.Parse(UtmSources["productId"]);
            }
        }


        /// <summary>
        /// Sessions the tracker identifier.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<string> SessionTrackerId(string value = null)
        {
            if (string.IsNullOrEmpty(value))
                return await _sessionStoreProvider.GetAsync<string>(sessionKeys.SessionTracker);

              await  _sessionStoreProvider.Set(sessionKeys.SessionTracker, value);
            return value;
            
        }

        /// <summary>
        /// ActivityId
        /// </summary>
        public async Task<Guid> ActivityId(Guid value)
        {
            if (value == Guid.Empty)
            {
                var activityValue = await _sessionStoreProvider.GetAsync<String>(sessionKeys.ActivityId);
                if (!string.IsNullOrEmpty(activityValue))
                {
                    return new Guid(activityValue);
                }

                activityValue = _cookieStoreProvider.Get(cookieKeys.ActivityId);
                if (!string.IsNullOrEmpty(activityValue))
                {
                    return new Guid(activityValue);
                }

                return Guid.NewGuid();
            }


            await _sessionStoreProvider.Set(sessionKeys.ActivityId, value, true);
            return value;

        }

        /// <summary>
        /// CustomerId
        /// </summary>
        public async Task<long> CustomerId(long? value = null)
        {
            if (value == null)
                return await _sessionStoreProvider.GetAsync<long>(sessionKeys.CustomerId);

            await _sessionStoreProvider.Set(sessionKeys.CustomerId, value);
            return value.Value;
        }

        
        public async Task<bool> IsUserAuthenticated(bool? isAuthentic = null)
        {
            if(isAuthentic == null)            
                return await _sessionStoreProvider.GetAsync<bool>(sessionKeys.isAuthenticated);
            
            
              await  _sessionStoreProvider.Set(sessionKeys.isAuthenticated, isAuthentic);
            return isAuthentic.Value;
        }

        public async Task<string> Email(string email = null)
        {
            if (string.IsNullOrEmpty(email))
                return await _sessionStoreProvider.GetAsync<string>(sessionKeys.Email);

            await _sessionStoreProvider.Set(sessionKeys.Email, email);

            return email;            
        }

        public async Task<Risk> Risk(Risk riskObj = null)
        {
            if (riskObj == null)
                return await _sessionStoreProvider.GetAsync<Risk>(sessionKeys.UserRisk);


            await _sessionStoreProvider.Set<Risk>(sessionKeys.UserRisk, riskObj, true);
            return riskObj;
        }
    }
}
