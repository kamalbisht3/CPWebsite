namespace Mena.CustomerPortal.Website
{
    using System;
    using System.IO.Compression;
    using Mena.Components.Core.Cache;
    using Mena.Components.Core.Cache.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Log4Net;
    using Mena.Components.Core.ServiceProxy;
    using Mena.Components.Redis.Contracts;
    using Mena.Components.Redis.Extensions;
    using Mena.Components.Web.Core.Contracts.Session;
    using Mena.Components.Web.Core.Session;
    using Mena.CustomerPortal.Website.Attributes;
    using Mena.CustomerPortal.Website.ConfigModel;
    using Mena.CustomerPortal.Website.ConfigModels;
    using Mena.CustomerPortal.Website.Constants;
    using Mena.CustomerPortal.Website.Helpers;
    using Mena.CustomerPortal.Website.Models;
    using Mena.CustomerPortal.Website.Session;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.DataProtection;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Http.Features;
    using Microsoft.AspNetCore.Mvc.ViewFeatures;
    using Microsoft.AspNetCore.ResponseCompression;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Options;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddResponseCompression((option) => { option.EnableForHttps = true; });

            services.Configure<GzipCompressionProviderOptions>(options =>
            {
                options.Level = CompressionLevel.Optimal;
            });
            // for server validation
            services.Configure<HtmlHelperOptions>(o => o.ClientValidationEnabled = false);
            services.AddRazorPages()
             .AddJsonOptions(option =>
             {
                 option.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
                 option.JsonSerializerOptions.IgnoreNullValues = true;
             }).AddControllersAsServices()
            .AddRazorPagesOptions(options =>
            {
                options.Conventions.AddPageRoute("/index", "{*url:regex(^((?!api|.css|.js|.png|.jpeg|.jpg|.pdf|.ico).)*$)}");
            });


            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => false;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            

            services.AddScoped<RequestSizeLimitConfAttribute>();  //ApplicationSettings
            services.Configure<ApplicationSettings>(options => Configuration.GetSection("ApplicationSettings").Bind(options));

            services.Configure<CdnPaths>(options => Configuration.GetSection("CdnPaths").Bind(options));
            services.Configure<CookieKeys>(options => Configuration.GetSection("CookieKeys").Bind(options));
            services.Configure<CookieSettings>(options => Configuration.GetSection("CookieSettings").Bind(options));
            services.Configure<EndPointUrls>(options => Configuration.GetSection("EndPointUrls").Bind(options));
            services.Configure<SessionKeys>(options => Configuration.GetSection("SessionKeys").Bind(options));
            services.Configure<EmailSenderConfig>(options => Configuration.GetSection("EmailSenderConfig").Bind(options));
            services.AddSingleton<IDeviceDetectionProvider, DeviceDetectionProvider>();
            services.AddSingleton<ISessionInitializer, DefaultSessionInitializer>();
            services.AddSingleton<ISessionStoreProvider, SessionStoreProvider>();
            services.AddSingleton<ICookieStoreProvider, CookieStoreProvider>();
            services.AddTransient<IWebSession, CustomerSession>();

            services.AddHttpContextAccessor();
            services.AddCustomDistributedRedisCache(Configuration)
                      .AddSingleton<IProxyCache>(provider => new RedisProxyCache(provider.GetRequiredService<IRedisCacheManager>()))
                      .AddDataProtection(item => item.ApplicationDiscriminator = Configuration["SessionSettings:ApplicationDiscriminator"])
                      .PersistKeysToRedisCache(Configuration, Configuration["SessionSettings:ProtectionKey"])
                      .SetApplicationName(Configuration["SessionSettings:ApplicationName"]);

            services.AddSingleton<ILogger>(item => new Logger(@"Configurations/Log4Net.xml", "CustomerPortal"));
            services.AddRestProxy();
            services.AddSession(item =>
            {
                item.Cookie.IsEssential = true;
                item.Cookie.Domain = Configuration["CookieSettings:Domain"];
                item.Cookie.Name = Configuration["CookieSettings:CookieName"];
                var TimeSpanDetails = Configuration.GetSection("SessionSettings").Get<SessionSettings>();
                item.IdleTimeout = TimeSpan.FromMinutes(Convert.ToDouble(TimeSpanDetails.SessionTimeout));
            });

            var appSettings = Configuration.GetSection("ApplicationSettings").Get<ApplicationSettings>();

            services.Configure<FormOptions>(options =>
            {
                options.ValueCountLimit = appSettings.MaxFileAllowed + 1;
                options.ValueLengthLimit = appSettings.MaxRequestLength;
                options.MultipartBodyLengthLimit = appSettings.MaxRequestLength;
                options.MemoryBufferThreshold = appSettings.MaxRequestLength;
            });

            services.AddRouting();

            services.AddCors(o => o.AddPolicy("CorePolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));
            SetConstantEndPoints(services);
        }

        private void SetConstantEndPoints(IServiceCollection services)
        {
            var serviceProvider = services.BuildServiceProvider();
            var endPointUrls = serviceProvider.GetService<IOptions<EndPointUrls>>();
            if (endPointUrls != null)
            {
                ApiEndpointUrls.LookUpWebApi = endPointUrls.Value.LookUpWebAPI;
                ApiEndpointUrls.CustomerPortalAPI = endPointUrls.Value.CustomerPortalAPI;
                ApiEndpointUrls.CommonEmailerAPI = endPointUrls.Value.CommonEmailerAPI;
            }

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseExceptionHandler(appError =>
                {
                    appError.Run(async context =>
                    {
                        context.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
                        context.Response.ContentType = "application/json";

                        var contextFeature = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>();
                        if (contextFeature != null)
                        {
                            //logger.LogError($"Something went wrong: {contextFeature.Error}");

                            await context.Response.WriteAsync(new
                            {
                                StatusCode = context.Response.StatusCode,
                                Message = "Internal Server Error."
                            }.ToString());
                        }
                    });
                });
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseSession();
            //app.UseHttpsRedirection();
            app.UseStaticFiles(new StaticFileOptions
            {
                OnPrepareResponse = ctx =>
                {
                    TimeSpan maxAge = new TimeSpan(0, 1, 0, 0);
                    ctx.Context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.CacheControl] =
                        "public,max-age=" + maxAge.TotalSeconds.ToString("0");
                }
            });

            app.UseResponseCompression();
            app.UseCookiePolicy();

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
                endpoints.MapControllers();

            });
        }
    }
}
