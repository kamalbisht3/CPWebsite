﻿
namespace Mena.Apis.CustomerPortal.Constants
{
    public class SpConstant
    {
        public const string UserAccount_insert = "[CP].[UserAccount_insert]";

        public const string PasswordValidate = "[CP].[PasswordValidate]";
        public const string PasswordResetRequest_insert = "[CP].[PasswordResetRequest_insert]";
        public const string PasswordResetValidateIdentifier = "[CP].[PasswordResetValidateIdentifier]";
        public const string PasswordReset = "[CP].[PasswordReset]";
        public const string PersonalInfo_Get = "[CP].[PersonalInfo_Get]";
        public const string VehicleInfo = "[CP].[VehicleVersion_Get]";
        public const string PolicyInfo = "[CP].[CustomerInformation_Get]";
        public const string QuoteHistory = "[CP].[QuoteHistory_Get]";
        public const string UploadImageData_insert = "[CP].[UploadImageData_Ins]";
        public const string UploadImageData_Get = "[CP].[UploadImageData_Get]";
        public const string UploadImageData_Delete = "[CP].[UploadImageData_Del]";
    }
}
