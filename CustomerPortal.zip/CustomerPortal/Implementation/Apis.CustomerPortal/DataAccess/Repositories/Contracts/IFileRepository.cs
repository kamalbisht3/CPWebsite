﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts
{
    using Mena.Apis.CustomerPortal.Contracts.Request.File;
    using Mena.Apis.CustomerPortal.Contracts.Response.File;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    public interface IFileRepository
    {
        /// <summary>
        /// FileInsert
        /// </summary>
        /// <param name="FileInsertRequest"></param>
        /// <returns></returns>
        Task<int> FileInsert(FileInsertRequest fileInsertRequest);
        /// <summary>
        /// FileGet
        /// </summary>
        /// <param name="fileGetRequest"></param>
        /// <returns></returns>
        Task<List<FileGetResult>> FileGet(FileGetRequest fileGetRequest);

        Task<int> DeleteFile(FileDeleteRequest fileDeleteRequest);
    }
}
