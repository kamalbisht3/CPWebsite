﻿namespace Mena.Api.Identity.DataAccess.Repositories.Contracts
{
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Request.Personal;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Response.Personal;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// IIdentityRepository
    /// </summary>
    public interface IPersonalRepository
    {

        /// <summary>
        /// Creates the forgot link.
        /// </summary>
        /// <param name="forgotLinkRequest">The forgot link request.</param>
        /// <returns></returns>
        Task<List<PersonalDetailResult>> GetPersonalDetail(PersonalDetailRequest personalDetailRequest);

    }
}
