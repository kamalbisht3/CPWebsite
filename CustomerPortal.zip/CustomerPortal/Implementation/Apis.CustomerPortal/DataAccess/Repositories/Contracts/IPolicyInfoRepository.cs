﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts
{
    using Mena.Apis.CustomerPortal.Contracts.Response.Policy;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public interface IPolicyInfoRepository
    {
        Task<List<PolicyInformation>> GetPolicyInfo(string EmailAddress);
    }
}
