﻿namespace Mena.Api.Identity.DataAccess.Repositories
{
    using Mena.Api.Identity.DataAccess.DBContext;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Mena.Api.Identity.DataAccess.Repositories.Contracts;
    using Mena.Apis.CustomerPortal.Constants;
    using Mena.Components.Core.Extensions.EntityFrameworkCore;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;


    /// <summary>
    /// IdentityRepository
    /// </summary>
    /// <seealso cref="IAuthRepository" />
    public class AuthRepository : IAuthRepository
    {
        /// <summary>
        /// The identity context
        /// </summary>
        private CustomerPortalContext _identityContext;
        /// <summary>
        /// Initializes a new instance of the <see cref="AtuhRepository"/> class.
        /// </summary>
        /// <param name="identityContext">The identity context.</param>
        public AuthRepository(CustomerPortalContext identityContext)
        {
            _identityContext = identityContext;
        }


        /// <summary>
        /// Inserts the customer.
        /// </summary>
        /// <param name="customer">The customer.</param>
        /// <returns></returns>
        


        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="userCreateRequest">The user create request.</param>
        /// <returns></returns>
        public Task<List<UserCreateResult>> CreateUser(UserCreateRequest userCreateRequest)
        {
            var sqlData = new Dictionary<string, object>
                {

                            {"EmailAddress",userCreateRequest.EmailAddress},
                            {"Password", userCreateRequest.Password}
                }.ToSql(SpConstant.UserAccount_insert);
            return _identityContext.FromSqlAsync<UserCreateResult>(sqlData.sqlString, sqlData.sqlParameters);
            
        }

        /// <summary>
        /// Creates the forgot link.
        /// </summary>
        /// <param name="forgotLinkRequest">The forgot link request.</param>
        /// <returns></returns>
        public Task<List<ForgotLinkResult>> CreateForgotLink(ForgotLinkRequest forgotLinkRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                            {"EmailAddress",forgotLinkRequest.EmailAddress},
                }.ToSql(SpConstant.PasswordResetRequest_insert);
            return _identityContext.FromSqlAsync<ForgotLinkResult>(sqlData.sqlString, sqlData.sqlParameters);
        }

        /// <summary>
        /// Validates the forgot link.
        /// </summary>
        /// <param name="forgotLinkValidRequest">The forgot link valid request.</param>
        /// <returns></returns>
        public Task<List<ForgotLinkValidResult>> ValidateForgotLink(ForgotLinkValidRequest forgotLinkValidRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                            {"Identifier",forgotLinkValidRequest.Identifier},
                }.ToSql(SpConstant.PasswordResetValidateIdentifier);
            return _identityContext.FromSqlAsync<ForgotLinkValidResult>(sqlData.sqlString, sqlData.sqlParameters);
        }

        /// <summary>
        /// Resets the password.
        /// </summary>
        /// <param name="passwordResetRequest">The password reset request.</param>
        /// <returns></returns>
        public Task<List<PasswordResetResult>> ResetPassword(PasswordResetRequest passwordResetRequest)
        {
            var sqlData = new Dictionary<string, object>
                {

                            {"EmailAddress",passwordResetRequest.EmailAddress},
                            {"Password", passwordResetRequest.Password}
                }.ToSql(SpConstant.PasswordReset);
            return _identityContext.FromSqlAsync<PasswordResetResult>(sqlData.sqlString, sqlData.sqlParameters);
        }

        /// <summary>
        /// Logins the validate.
        /// </summary>
        /// <param name="loginValidateRequest">The login validate request.</param>
        /// <returns></returns>
        public Task<List<LoginValidateResult>> LoginValidate(LoginValidateRequest loginValidateRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                            {"EmailAddress",loginValidateRequest.EmailAddress},
                            {"Password", loginValidateRequest.Password}
                }.ToSql(SpConstant.PasswordValidate);
            return _identityContext.FromSqlAsync<LoginValidateResult>(sqlData.sqlString, sqlData.sqlParameters);
        }
    }
}
