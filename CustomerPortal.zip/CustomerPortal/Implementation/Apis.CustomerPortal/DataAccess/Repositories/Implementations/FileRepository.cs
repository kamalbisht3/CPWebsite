﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Implementations
{
    using Mena.Api.Identity.DataAccess.DBContext;
    using Mena.Apis.CustomerPortal.Constants;
    using Mena.Apis.CustomerPortal.Contracts.Request.File;
    using Mena.Apis.CustomerPortal.Contracts.Response.File;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Extensions.EntityFrameworkCore;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    public class FileRepository: IFileRepository
    {
        /// <summary>
        /// The identity context
        /// </summary>
        private CustomerPortalContext _identityContext;
        public FileRepository(CustomerPortalContext identityContext)
        {
            _identityContext = identityContext;
        }

        public Task<int> FileInsert(FileInsertRequest fileInsertRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                            {"Data",fileInsertRequest.Data },
                            {"EmailAddress",fileInsertRequest.EmailAddress},

                }.ToSql(SpConstant.UploadImageData_insert);
            return _identityContext.FromSqlCommandAsync(sqlData.sqlString, sqlData.sqlParameters);
            
        }

        public Task<List<FileGetResult>> FileGet(FileGetRequest fileGetRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                            {"EmailAddress",fileGetRequest.EmailAddress},

                }.ToSql(SpConstant.UploadImageData_Get);
            return _identityContext.FromSqlAsync<FileGetResult>(sqlData.sqlString, sqlData.sqlParameters);
        }

        public Task<int> DeleteFile(FileDeleteRequest fileDeleteRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                {"UploadimageDataID",  fileDeleteRequest.UploadimageDataID},
                            {"EmailAddress",fileDeleteRequest.EmailID},

                }.ToSql(SpConstant.UploadImageData_Delete);

            return _identityContext.FromSqlCommandAsync(sqlData.sqlString, sqlData.sqlParameters);
        }
    }
   
}
