﻿namespace Mena.Api.Identity.DataAccess.Repositories
{
    using Mena.Api.Identity.DataAccess.DBContext;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Mena.Api.Identity.DataAccess.Repositories.Contracts;
    using Mena.Apis.CustomerPortal.Constants;
    using Mena.Components.Core.Extensions.EntityFrameworkCore;
    using Mena.Apis.CustomerPortal.Contracts.Response.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Request.Auth;
    using Mena.Apis.CustomerPortal.Contracts.Request.Personal;
    using Mena.Apis.CustomerPortal.Contracts.Response.Personal;


    /// <summary>
    /// IdentityRepository
    /// </summary>
    /// <seealso cref="IAuthRepository" />
    public class PersonalRepository : IPersonalRepository
    {
        /// <summary>
        /// The identity context
        /// </summary>
        private CustomerPortalContext _identityContext;
        /// <summary>
        /// Initializes a new instance of the <see cref="AtuhRepository"/> class.
        /// </summary>
        /// <param name="identityContext">The identity context.</param>
        public PersonalRepository(CustomerPortalContext identityContext)
        {
            _identityContext = identityContext;
        }

        
        public Task<List<PersonalDetailResult>> GetPersonalDetail(PersonalDetailRequest personalDetailRequest)
        {
            var sqlData = new Dictionary<string, object>
                {
                            {"EmailAddress",personalDetailRequest.EmailAddress},
                }.ToSql(SpConstant.PersonalInfo_Get);
            return _identityContext.FromSqlAsync<PersonalDetailResult>(sqlData.sqlString, sqlData.sqlParameters);
            
        }

    }
}
