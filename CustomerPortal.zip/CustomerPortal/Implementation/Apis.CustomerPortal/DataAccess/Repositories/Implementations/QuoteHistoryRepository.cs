﻿namespace Mena.Apis.CustomerPortal.DataAccess.Repositories.Implementations
{
    using Mena.Api.Identity.DataAccess.DBContext;
    using Mena.Apis.CustomerPortal.Constants;
    using Mena.Apis.CustomerPortal.Contracts.Response.QuoteHistory;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Extensions.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class QuoteHistoryRepository : IQuoteHistoryRepository
    {
        private CustomerPortalContext _identityContext;

        public QuoteHistoryRepository(CustomerPortalContext identityContext)
        {
            _identityContext = identityContext;
        }

        public Task<List<QuoteHistory>> GetQuoteHistory(string email)
        {
            var sqlData = new Dictionary<string, object>
                {
                    {"EmailAddress",email}
                }.ToSql(SpConstant.QuoteHistory);
            return _identityContext.FromSqlAsync<QuoteHistory>(sqlData.sqlString, sqlData.sqlParameters);
        }
    }
}
