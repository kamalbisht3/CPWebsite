namespace Mena.Apis.CustomerPortal
{
    using Mena.Api.Identity.DataAccess.DBContext;
    using Mena.Api.Identity.DataAccess.Repositories;
    using Mena.Api.Identity.DataAccess.Repositories.Contracts;
    using Mena.Components.Core.Instrumentation.Contracts;
    using Mena.Components.Core.Instrumentation.Log4Net;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.EntityFrameworkCore;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Contracts;
    using Mena.Apis.CustomerPortal.DataAccess.Repositories.Implementations;
    using Microsoft.AspNetCore.Http;
    using System.Net;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers()
                .AddJsonOptions(option =>
                {
                    option.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
                    option.JsonSerializerOptions.IgnoreNullValues = true;
                }).AddControllersAsServices();

            services.AddDbContext<CustomerPortalContext>(o => o.UseSqlServer(Configuration.GetConnectionString("IdentityConnection")));
            services.AddScoped<IAuthRepository, AuthRepository>();
            services.AddScoped<IVehicleRepository, VehicleRepository>();
            services.AddScoped<IPersonalRepository, PersonalRepository>();
            services.AddScoped<IPolicyInfoRepository, PolicyInfoRepository>();
            services.AddScoped<IQuoteHistoryRepository, QuoteHistoryRepository>();
            services.AddScoped<IFileRepository, FileRepository>();
            services.AddSingleton<ILogger>(item => new Logger("Log4Net.xml", "LookupService"));

            services.AddRouting();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseExceptionHandler(appError =>
                {
                    appError.Run(async context =>
                    {
                        context.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
                        context.Response.ContentType = "application/json";

                        var contextFeature = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>();
                        if (contextFeature != null)
                        {
                            //logger.LogError($"Something went wrong: {contextFeature.Error}");

                            await context.Response.WriteAsync(new
                            {
                                StatusCode = context.Response.StatusCode,
                                Message = "Internal Server Error."
                            }.ToString());
                        }
                    });
                });
            }
           
            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
